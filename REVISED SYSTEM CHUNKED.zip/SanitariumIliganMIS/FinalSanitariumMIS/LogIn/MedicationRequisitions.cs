﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalSanitariumMIS.Helpers;
using IBM.Data.DB2;

namespace LogIn
{
    public partial class MedicationRequisitions : Form
    {
        private DatabaseHelper DB;
        private List<String> listPatients;
        private List<String> listNurses;
        private List<String> listDrugs;

        public MedicationRequisitions()
        {
            InitializeComponent();
            DB = new DatabaseHelper();
            loadReleasedMedications();
            loadComboBoxCollections();
        }

        private void loadReleasedMedications()
        {
            String Condition = "";
            String[] list_filters = new string[] {
                "STAFF.firstname","STAFF.lastname","PATIENT.FIRSTNAME","PATIENT.LASTNAME"
            };

            if (tb_search.Text != "")
            {
                Condition = " AND " + list_filters[cb_search_filter.SelectedIndex] + " LIKE '" + tb_search.Text + "%'";
            }

            dgv_list_medications.Columns.Clear();
            dgv_list_medications.Columns.Add("","Release ID");
            dgv_list_medications.Columns.Add("", "Patient ID");
            dgv_list_medications.Columns.Add("", "Patient");
            dgv_list_medications.Columns.Add("", "Nurse ID");
            dgv_list_medications.Columns.Add("", "Nurse");
            dgv_list_medications.Columns.Add("", "Date Released");

            //MessageBox.Show("SELECT medication.*, staff.firstname as staff_firstname, staff.lastname as staff_lastname, inpatientrecord.PATIENT_NUMBER, inpatientrecord.STAFF_NUMBER as DOCTOR_ID, inpatientrecord.WARD_NUMBER, inpatientrecord.BED_ID, patient.firstname, patient.lastname FROM medication, staff, inpatientrecord, patient WHERE medication.STAFF_NUMBER = staff.STAFF_NUMBER AND medication.INPATIENT_ID = inpatientrecord.INPATIENT_ID AND inpatientrecord.PATIENT_NUMBER = patient.PATIENT_NUMBER " + Condition);
            DB2ResultSet res = DB.QueryWithResultSet("SELECT medication.*, staff.firstname as staff_firstname, staff.lastname as staff_lastname, inpatientrecord.PATIENT_NUMBER, inpatientrecord.STAFF_NUMBER as DOCTOR_ID, inpatientrecord.WARD_NUMBER, inpatientrecord.BED_ID, patient.firstname, patient.lastname FROM medication, staff , inpatientrecord, patient WHERE medication.STAFF_NUMBER = staff.STAFF_NUMBER AND medication.INPATIENT_ID = inpatientrecord.INPATIENT_ID AND inpatientrecord.PATIENT_NUMBER = patient.PATIENT_NUMBER " + Condition);

            dgv_list_medications.Rows.Clear();

            while(res.Read())
            {
                dgv_list_medications.Rows.Add(new String[] {
                    res["MEDICATION_ID"].ToString(),
                    res["PATIENT_NUMBER"].ToString(),
                    res["FIRSTNAME"].ToString() + " " + res["LASTNAME"].ToString(),
                    res["STAFF_NUMBER"].ToString(),
                    res["STAFF_FIRSTNAME"].ToString() + " " + res["STAFF_LASTNAME"].ToString(),
                    res["DATE_FILED"].ToString()
                });
            }
        }

        private void loadReleasedMedicationsDetails()
        {
            DB2ResultSet res = DB.QueryWithResultSet("SELECT MEDICATIONDETAIL.MEDICATION_ID, MEDICATIONDETAIL.ITEM_NUMBER, SUPPLY.ITEM_NAME, MEDICATION.STAFF_NUMBER, MEDICATION.DATE_FILED, MEDICATION.INPATIENT_ID, MEDICATIONDETAIL.METHOD_OF_ADMINISTRATION, MEDICATIONDETAIL.DOSAGE FROM MEDICATIONDETAIL, MEDICATION, SUPPLY WHERE MEDICATIONDETAIL.MEDICATION_ID = MEDICATION.MEDICATION_ID AND MEDICATIONDETAIL.ITEM_NUMBER = SUPPLY.ITEM_NUMBER");

            String[] list_filters = new string[] {
                "FNAME","LNAME","ITEM_NAME","METHOD_OF_ADMINISTRATION","FIRSTNAME","LASTNAME"
            };
            // 0 - Patient Firstname, Patient Lastname, Drug, Method, Nurse Firstname, Nurse Lastname

            dgv_list_medications.Columns.Clear();
            dgv_list_medications.Columns.Add("", "Medication ID");
            dgv_list_medications.Columns.Add("", "Patient ID");
            dgv_list_medications.Columns.Add("", "Patient");
            dgv_list_medications.Columns.Add("", "Drug ID");
            dgv_list_medications.Columns.Add("", "Drug");
            dgv_list_medications.Columns.Add("", "Method of Administration");
            dgv_list_medications.Columns.Add("", "Dosage");
            dgv_list_medications.Columns.Add("", "Nurse ID");
            dgv_list_medications.Columns.Add("", "Nurse");
            dgv_list_medications.Columns.Add("", "Date Released");

            dgv_list_medications.Rows.Clear();

            while (res.Read())
            {
                DB2ResultSet rs1 = DB.QueryWithResultSet("SELECT INPATIENTRECORD.PATIENT_NUMBER, INPATIENTRECORD.WARD_NUMBER, PATIENT.FIRSTNAME as FNAME, PATIENT.LASTNAME as LNAME FROM INPATIENTRECORD, PATIENT WHERE INPATIENTRECORD.PATIENT_NUMBER = PATIENT.PATIENT_NUMBER AND INPATIENT_ID = " + res["INPATIENT_ID"].ToString());
                rs1.Read();

                DB2ResultSet rs2 = DB.QueryWithResultSet("SELECT * FROM STAFF WHERE STAFF_NUMBER = '" + res["STAFF_NUMBER"].ToString() + "'");
                rs2.Read();

                String[] row = new String[] {
                    res["MEDICATION_ID"].ToString(),
                    rs1["PATIENT_NUMBER"].ToString(),
                    rs1["FNAME"].ToString() + " " + rs1["LNAME"].ToString(),
                    res["ITEM_NUMBER"].ToString(),
                    res["ITEM_NAME"].ToString(),
                    res["METHOD_OF_ADMINISTRATION"].ToString(),
                    res["DOSAGE"].ToString(),
                    res["STAFF_NUMBER"].ToString(),
                    rs2["FIRSTNAME"].ToString() + " " + rs2["LASTNAME"].ToString(),
                    res["DATE_FILED"].ToString()
                };

                if (cb_search_filter.SelectedIndex > -1)
                {
                    String s = "";

                    try
                    {
                        if (rs1[list_filters[cb_search_filter.SelectedIndex]] != null)
                        {
                            s = rs1[list_filters[cb_search_filter.SelectedIndex]].ToString();
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    try
                    {
                        if (res[list_filters[cb_search_filter.SelectedIndex]] != null)
                        {
                            s = res[list_filters[cb_search_filter.SelectedIndex]].ToString();
                        }
                    }
                    catch (Exception ex1)
                    {

                    }

                    try
                    {
                        if (rs2[list_filters[cb_search_filter.SelectedIndex]] != null)
                        {
                            s = rs2[list_filters[cb_search_filter.SelectedIndex]].ToString();
                        }
                    }
                    catch (Exception ex2)
                    {

                    }

                    if (s.Contains(tb_search.Text))
                    {
                        dgv_list_medications.Rows.Add(row);
                    }
                }
                else
                {
                    dgv_list_medications.Rows.Add(row);
                }
            }
        }

        private void loadComboBoxCollections()
        {
            DB2ResultSet rs = DB.QueryWithResultSet("SELECT INPATIENTRECORD.*, PATIENT.FIRSTNAME, PATIENT.LASTNAME FROM INPATIENTRECORD, PATIENT WHERE PATIENT.PATIENT_NUMBER = INPATIENTRECORD.PATIENT_NUMBER AND DATE_LEFT IS NULL");
            listPatients = new List<String>();
            listNurses = new List<String>();
            listDrugs = new List<String>();

            while (rs.Read())
            {
                cb_patients.Items.Add(rs["FIRSTNAME"].ToString() + " " + rs["LASTNAME"].ToString());
                listPatients.Add(rs["INPATIENT_ID"].ToString());
            }

            rs = DB.QueryWithResultSet("SELECT * FROM STAFF");

            while (rs.Read())
            {
                DB2ResultSet r = DB.QueryWithResultSet("SELECT * FROM POSITIONHELD WHERE STAFF_NUMBER = '" + rs["STAFF_NUMBER"].ToString() + "' ORDER BY DATE_ASSIGNED DESC LIMIT 1"); // nurse only

                if (r.Read())
                {
                    if (r["POSITION_ID"].ToString() == "2")
                    {
                        cb_nurses.Items.Add(rs["FIRSTNAME"].ToString() + " " + rs["LASTNAME"].ToString());
                        listNurses.Add(rs["STAFF_NUMBER"].ToString());
                    }
                }
            }

            rs = DB.QueryWithResultSet("SELECT * FROM SUPPLY WHERE ITEM_TYPE = 'Drugs'");

            while (rs.Read())
            {
                cb_drugname.Items.Add(rs["ITEM_NAME"].ToString());
                listDrugs.Add(rs["ITEM_NUMBER"].ToString());
            }
        }

        private void linkback_Click(object sender, EventArgs e)
        {

        }

        private void MedicationRequisitions_Load(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if (!cb_detailed_view.Checked)
            {
                loadReleasedMedications();
            }
            else
            {
                loadReleasedMedicationsDetails();
            }
        }

        private void cb_detailed_view_CheckedChanged(object sender, EventArgs e)
        {
            if (!cb_detailed_view.Checked)
            {
                loadReleasedMedications();

                cb_search_filter.Items.Clear();
                cb_search_filter.Items.AddRange(new String[]{
                    "Nurse Firstname",
                    "Nurse Lastname",
                    "Patient Firstname",
                    "Patient Lastname"
                });
            }
            else
            {
                loadReleasedMedicationsDetails();
                cb_search_filter.Items.Clear();
                cb_search_filter.Items.AddRange(new String[]{
                    "Patient Firstname",
                    "Patient Lastname",
                    "Drug",
                    "Method",
                    "Nurse Firstname",
                    "Nurse Lastname",
                });
            }
        }

        private void MedicationRequisitions_FormClosed(object sender, FormClosedEventArgs e)
        {
            new MedDirMainMenu().Show();
        }

        private void btn_select_nurse_Click(object sender, EventArgs e)
        {

        }

        private void btn_select_patient_Click(object sender, EventArgs e)
        {

        }

        private void btn_select_drug_Click(object sender, EventArgs e)
        {
            if (tb_dosage.Text == "" || tb_method.Text == "" || cb_drugname.SelectedIndex < 0)
            {
                MessageBox.Show("Please Fill-in Required Fields");
                return;
            }

            dgv_list_selected_drugs.Rows.Add(new String[] {
                listDrugs[cb_drugname.SelectedIndex],
                cb_drugname.SelectedItem.ToString(),
                tb_method.Text,
                tb_dosage.Text
            });
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (dgv_list_selected_drugs.SelectedRows.Count < 1)
            {
                MessageBox.Show("Select an item form the list of selected medications");
                return;
            }

            dgv_list_selected_drugs.Rows.RemoveAt(dgv_list_selected_drugs.CurrentRow.Index);
        }

        private void btn_save_request_Click(object sender, EventArgs e)
        {
            if (dgv_list_selected_drugs.Rows.Count < 1 || cb_patients.SelectedIndex < 0 || cb_nurses.SelectedIndex < 0 || cb_drugname.SelectedIndex < 0)
            {
                MessageBox.Show("Please fill-in required fields!");
                return;
            }

            bool ok = DB.Query("INSERT INTO MEDICATION VALUES(" + tb_medication_number.Text + ",'" + listNurses[cb_nurses.SelectedIndex] + "','" + listPatients[cb_patients.SelectedIndex] + "',CURRENT_TIMESTAMP)");

            foreach (DataGridViewRow r in dgv_list_selected_drugs.Rows)
            { 
                DB.Query("INSERT INTO MEDICATIONDETAIL (MEDICATION_ID, ITEM_NUMBER, METHOD_OF_ADMINISTRATION, DOSAGE) VALUES ("+ tb_medication_number.Text + "," + r.Cells[0].Value.ToString() + ",'" + r.Cells[2].Value.ToString() + "','" + r.Cells[3].Value.ToString() + "')");
            }

            if(ok)
            {
                MessageBox.Show("Medication Saved!");
            }
        }
    }
}
