﻿namespace LogIn
{
    partial class RoomManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkback = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtbeddesc = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnudpatebed = new System.Windows.Forms.Button();
            this.cblocward = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbavailability = new System.Windows.Forms.ComboBox();
            this.dgvbeds = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label10 = new System.Windows.Forms.Label();
            this.txtbednum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnaddbed = new System.Windows.Forms.Button();
            this.dgvwards = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnupdateward = new System.Windows.Forms.Button();
            this.txtwarddesc = new System.Windows.Forms.TextBox();
            this.btnaddward = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtwardname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtwardnum = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbeds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvwards)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.linkback);
            this.panel1.Location = new System.Drawing.Point(-3, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1538, 123);
            this.panel1.TabIndex = 91;
            // 
            // linkback
            // 
            this.linkback.AutoSize = true;
            this.linkback.Font = new System.Drawing.Font("Calibri", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkback.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.linkback.Location = new System.Drawing.Point(811, 84);
            this.linkback.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.linkback.Name = "linkback";
            this.linkback.Size = new System.Drawing.Size(240, 29);
            this.linkback.TabIndex = 106;
            this.linkback.Text = "Go back to Main Menu";
            this.linkback.Click += new System.EventHandler(this.linkback_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtbeddesc);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.btnudpatebed);
            this.groupBox2.Controls.Add(this.cblocward);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cbavailability);
            this.groupBox2.Controls.Add(this.dgvbeds);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtbednum);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.btnaddbed);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(13, 465);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(942, 333);
            this.groupBox2.TabIndex = 92;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "BED DETAILS";
            // 
            // txtbeddesc
            // 
            this.txtbeddesc.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbeddesc.Location = new System.Drawing.Point(225, 159);
            this.txtbeddesc.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtbeddesc.Multiline = true;
            this.txtbeddesc.Name = "txtbeddesc";
            this.txtbeddesc.Size = new System.Drawing.Size(211, 52);
            this.txtbeddesc.TabIndex = 101;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 165);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 18);
            this.label9.TabIndex = 100;
            this.label9.Text = "DESCRIPTION:";
            // 
            // btnudpatebed
            // 
            this.btnudpatebed.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnudpatebed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnudpatebed.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnudpatebed.Location = new System.Drawing.Point(235, 226);
            this.btnudpatebed.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnudpatebed.Name = "btnudpatebed";
            this.btnudpatebed.Size = new System.Drawing.Size(203, 43);
            this.btnudpatebed.TabIndex = 94;
            this.btnudpatebed.Text = "UPDATE BED";
            this.btnudpatebed.UseVisualStyleBackColor = false;
            this.btnudpatebed.Click += new System.EventHandler(this.btnudpatebed_Click);
            // 
            // cblocward
            // 
            this.cblocward.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cblocward.FormattingEnabled = true;
            this.cblocward.Location = new System.Drawing.Point(224, 84);
            this.cblocward.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cblocward.Name = "cblocward";
            this.cblocward.Size = new System.Drawing.Size(212, 26);
            this.cblocward.TabIndex = 93;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(479, 14);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 24);
            this.label2.TabIndex = 95;
            this.label2.Text = "BED LIST:";
            // 
            // cbavailability
            // 
            this.cbavailability.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbavailability.FormattingEnabled = true;
            this.cbavailability.Location = new System.Drawing.Point(224, 123);
            this.cbavailability.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbavailability.Name = "cbavailability";
            this.cbavailability.Size = new System.Drawing.Size(212, 26);
            this.cbavailability.TabIndex = 86;
            // 
            // dgvbeds
            // 
            this.dgvbeds.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvbeds.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgvbeds.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvbeds.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column7});
            this.dgvbeds.Location = new System.Drawing.Point(465, 42);
            this.dgvbeds.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvbeds.Name = "dgvbeds";
            this.dgvbeds.RowHeadersVisible = false;
            this.dgvbeds.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvbeds.Size = new System.Drawing.Size(413, 255);
            this.dgvbeds.TabIndex = 94;
            this.dgvbeds.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvbeds_CellContentDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "BED_NUM";
            this.Column1.Name = "Column1";
            this.Column1.Width = 128;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "AVAILABILITY";
            this.Column2.Name = "Column2";
            this.Column2.Width = 158;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "LOCATION";
            this.Column3.Name = "Column3";
            this.Column3.Width = 131;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "DESCRIPTION";
            this.Column7.Name = "Column7";
            this.Column7.Width = 162;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 127);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 18);
            this.label10.TabIndex = 87;
            this.label10.Text = "AVAILABILITY:";
            // 
            // txtbednum
            // 
            this.txtbednum.Enabled = false;
            this.txtbednum.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbednum.Location = new System.Drawing.Point(224, 42);
            this.txtbednum.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtbednum.Name = "txtbednum";
            this.txtbednum.Size = new System.Drawing.Size(212, 26);
            this.txtbednum.TabIndex = 60;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 18);
            this.label1.TabIndex = 59;
            this.label1.Text = "BED NUMBER:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(20, 87);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(126, 18);
            this.label15.TabIndex = 56;
            this.label15.Text = "LOCATION (WARD):";
            // 
            // btnaddbed
            // 
            this.btnaddbed.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnaddbed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnaddbed.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddbed.Location = new System.Drawing.Point(24, 226);
            this.btnaddbed.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnaddbed.Name = "btnaddbed";
            this.btnaddbed.Size = new System.Drawing.Size(203, 43);
            this.btnaddbed.TabIndex = 93;
            this.btnaddbed.Text = "ADD BED";
            this.btnaddbed.UseVisualStyleBackColor = false;
            this.btnaddbed.Click += new System.EventHandler(this.btnaddbed_Click);
            // 
            // dgvwards
            // 
            this.dgvwards.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvwards.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgvwards.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvwards.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvwards.Location = new System.Drawing.Point(507, 42);
            this.dgvwards.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvwards.Name = "dgvwards";
            this.dgvwards.RowHeadersVisible = false;
            this.dgvwards.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvwards.Size = new System.Drawing.Size(977, 255);
            this.dgvwards.TabIndex = 99;
            this.dgvwards.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvwards_CellContentDoubleClick);
            // 
            // Column4
            // 
            this.Column4.HeaderText = "WARD_NUM";
            this.Column4.Name = "Column4";
            this.Column4.Width = 145;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "NAME";
            this.Column5.Name = "Column5";
            this.Column5.Width = 90;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "DESCRIPTION";
            this.Column6.Name = "Column6";
            this.Column6.Width = 162;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.btnupdateward);
            this.groupBox4.Controls.Add(this.dgvwards);
            this.groupBox4.Controls.Add(this.txtwarddesc);
            this.groupBox4.Controls.Add(this.btnaddward);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.txtwardname);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.txtwardnum);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(13, 130);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(1506, 327);
            this.groupBox4.TabIndex = 99;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "WARD DETAILS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(503, 18);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 24);
            this.label8.TabIndex = 96;
            this.label8.Text = "WARD LIST:";
            // 
            // btnupdateward
            // 
            this.btnupdateward.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnupdateward.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupdateward.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdateward.Location = new System.Drawing.Point(267, 196);
            this.btnupdateward.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnupdateward.Name = "btnupdateward";
            this.btnupdateward.Size = new System.Drawing.Size(211, 43);
            this.btnupdateward.TabIndex = 98;
            this.btnupdateward.Text = "UPDATE WARD";
            this.btnupdateward.UseVisualStyleBackColor = false;
            this.btnupdateward.Click += new System.EventHandler(this.btnupdateward_Click);
            // 
            // txtwarddesc
            // 
            this.txtwarddesc.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwarddesc.Location = new System.Drawing.Point(249, 121);
            this.txtwarddesc.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtwarddesc.Multiline = true;
            this.txtwarddesc.Name = "txtwarddesc";
            this.txtwarddesc.Size = new System.Drawing.Size(229, 52);
            this.txtwarddesc.TabIndex = 89;
            // 
            // btnaddward
            // 
            this.btnaddward.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnaddward.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnaddward.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddward.Location = new System.Drawing.Point(18, 196);
            this.btnaddward.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnaddward.Name = "btnaddward";
            this.btnaddward.Size = new System.Drawing.Size(211, 43);
            this.btnaddward.TabIndex = 97;
            this.btnaddward.Text = "ADD WARD";
            this.btnaddward.UseVisualStyleBackColor = false;
            this.btnaddward.Click += new System.EventHandler(this.btnaddward_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 87);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 18);
            this.label7.TabIndex = 56;
            this.label7.Text = "WARD NAME:";
            // 
            // txtwardname
            // 
            this.txtwardname.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwardname.Location = new System.Drawing.Point(249, 84);
            this.txtwardname.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtwardname.Name = "txtwardname";
            this.txtwardname.Size = new System.Drawing.Size(229, 26);
            this.txtwardname.TabIndex = 88;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(41, 46);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 18);
            this.label6.TabIndex = 59;
            this.label6.Text = "WARD NUMBER:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 127);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 18);
            this.label5.TabIndex = 87;
            this.label5.Text = "DESCRIPTION:";
            // 
            // txtwardnum
            // 
            this.txtwardnum.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwardnum.Location = new System.Drawing.Point(249, 42);
            this.txtwardnum.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtwardnum.Name = "txtwardnum";
            this.txtwardnum.Size = new System.Drawing.Size(229, 26);
            this.txtwardnum.TabIndex = 60;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Raleway", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(28, 68);
            this.label20.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(265, 31);
            this.label20.TabIndex = 108;
            this.label20.Text = "Room Management";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Raleway", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(25, 22);
            this.label23.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(437, 44);
            this.label23.TabIndex = 107;
            this.label23.Text = "SANITARIUM HOSPITAL";
            // 
            // RoomManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1532, 741);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "RoomManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ROOM MANAGEMENT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.RoomManagement_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbeds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvwards)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cblocward;
        private System.Windows.Forms.ComboBox cbavailability;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtbednum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnaddbed;
        private System.Windows.Forms.DataGridView dgvbeds;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvwards;
        private System.Windows.Forms.Label linkback;
        private System.Windows.Forms.Button btnudpatebed;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtwarddesc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtwardname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtwardnum;
        private System.Windows.Forms.Button btnaddward;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnupdateward;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.TextBox txtbeddesc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
    }
}