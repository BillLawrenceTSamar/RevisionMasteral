﻿namespace LogIn
{
    partial class StaffManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlEmployeeBG = new System.Windows.Forms.Panel();
            this.lblEmpName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnaddWE = new System.Windows.Forms.Button();
            this.btnremoveWE = new System.Windows.Forms.Button();
            this.dgvworkexperiences = new System.Windows.Forms.DataGridView();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnchangeWE = new System.Windows.Forms.Button();
            this.dtp_work_experrience_finish = new System.Windows.Forms.DateTimePicker();
            this.dtp_work_experrience_start = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtOrganization = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnaddQuali = new System.Windows.Forms.Button();
            this.btnremoveQuali = new System.Windows.Forms.Button();
            this.btnchangeQuali = new System.Windows.Forms.Button();
            this.dgvqualifications = new System.Windows.Forms.DataGridView();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtQualification = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dgvStaffList = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtNIN = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbsex = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dpbirthdate = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txttelnumber = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtstaffnumber = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnPromoteDemote = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.btnemployeebg = new System.Windows.Forms.Button();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.cb_search_filter = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.pnlEmployeeBG.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvworkexperiences)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvqualifications)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaffList)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(-7, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1343, 123);
            this.panel1.TabIndex = 38;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Raleway", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(24, 65);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 35);
            this.label4.TabIndex = 9;
            this.label4.Text = "Staff Records";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Raleway", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(447, 45);
            this.label3.TabIndex = 8;
            this.label3.Text = "SANITARIUM HOSPITAL";
            // 
            // pnlEmployeeBG
            // 
            this.pnlEmployeeBG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEmployeeBG.BackColor = System.Drawing.Color.MediumAquamarine;
            this.pnlEmployeeBG.Controls.Add(this.lblEmpName);
            this.pnlEmployeeBG.Controls.Add(this.panel2);
            this.pnlEmployeeBG.Controls.Add(this.groupBox3);
            this.pnlEmployeeBG.Controls.Add(this.groupBox2);
            this.pnlEmployeeBG.Location = new System.Drawing.Point(22, 151);
            this.pnlEmployeeBG.Margin = new System.Windows.Forms.Padding(4);
            this.pnlEmployeeBG.Name = "pnlEmployeeBG";
            this.pnlEmployeeBG.Size = new System.Drawing.Size(1295, 608);
            this.pnlEmployeeBG.TabIndex = 20;
            // 
            // lblEmpName
            // 
            this.lblEmpName.AutoSize = true;
            this.lblEmpName.Font = new System.Drawing.Font("Raleway", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmpName.ForeColor = System.Drawing.Color.Black;
            this.lblEmpName.Location = new System.Drawing.Point(21, 17);
            this.lblEmpName.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblEmpName.Name = "lblEmpName";
            this.lblEmpName.Size = new System.Drawing.Size(327, 44);
            this.lblEmpName.TabIndex = 43;
            this.lblEmpName.Text = "EMPLOYEE NAME";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnchangeQuali);
            this.panel2.Controls.Add(this.btnchangeWE);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1295, 63);
            this.panel2.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1201, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 32);
            this.button1.TabIndex = 46;
            this.button1.Text = "CLOSE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.btnaddWE);
            this.groupBox3.Controls.Add(this.btnremoveWE);
            this.groupBox3.Controls.Add(this.dgvworkexperiences);
            this.groupBox3.Controls.Add(this.dtp_work_experrience_finish);
            this.groupBox3.Controls.Add(this.dtp_work_experrience_start);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txtOrganization);
            this.groupBox3.Controls.Add(this.txtPosition);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(29, 325);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(1235, 263);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "WORK EXPERIENCE";
            // 
            // btnaddWE
            // 
            this.btnaddWE.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnaddWE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnaddWE.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddWE.Location = new System.Drawing.Point(177, 205);
            this.btnaddWE.Margin = new System.Windows.Forms.Padding(4);
            this.btnaddWE.Name = "btnaddWE";
            this.btnaddWE.Size = new System.Drawing.Size(129, 38);
            this.btnaddWE.TabIndex = 45;
            this.btnaddWE.Text = "ADD";
            this.btnaddWE.UseVisualStyleBackColor = false;
            this.btnaddWE.Click += new System.EventHandler(this.btnaddWE_Click);
            // 
            // btnremoveWE
            // 
            this.btnremoveWE.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnremoveWE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnremoveWE.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremoveWE.Location = new System.Drawing.Point(314, 205);
            this.btnremoveWE.Margin = new System.Windows.Forms.Padding(4);
            this.btnremoveWE.Name = "btnremoveWE";
            this.btnremoveWE.Size = new System.Drawing.Size(129, 38);
            this.btnremoveWE.TabIndex = 44;
            this.btnremoveWE.Text = "REMOVE";
            this.btnremoveWE.UseVisualStyleBackColor = false;
            this.btnremoveWE.Click += new System.EventHandler(this.btnremoveWE_Click);
            // 
            // dgvworkexperiences
            // 
            this.dgvworkexperiences.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvworkexperiences.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvworkexperiences.BackgroundColor = System.Drawing.Color.MediumSpringGreen;
            this.dgvworkexperiences.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvworkexperiences.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15});
            this.dgvworkexperiences.Location = new System.Drawing.Point(583, 36);
            this.dgvworkexperiences.Margin = new System.Windows.Forms.Padding(4);
            this.dgvworkexperiences.Name = "dgvworkexperiences";
            this.dgvworkexperiences.RowHeadersVisible = false;
            this.dgvworkexperiences.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvworkexperiences.Size = new System.Drawing.Size(619, 207);
            this.dgvworkexperiences.TabIndex = 0;
            this.dgvworkexperiences.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvworkexperiences_CellContenDoubleClick);
            // 
            // Column11
            // 
            this.Column11.HeaderText = "WE_ID";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "POSITION";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "ORGANIZATION";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "START_DATE";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "END_DATE";
            this.Column15.Name = "Column15";
            // 
            // btnchangeWE
            // 
            this.btnchangeWE.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnchangeWE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnchangeWE.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchangeWE.Location = new System.Drawing.Point(830, 16);
            this.btnchangeWE.Margin = new System.Windows.Forms.Padding(4);
            this.btnchangeWE.Name = "btnchangeWE";
            this.btnchangeWE.Size = new System.Drawing.Size(129, 38);
            this.btnchangeWE.TabIndex = 43;
            this.btnchangeWE.Text = "CHANGE";
            this.btnchangeWE.UseVisualStyleBackColor = false;
            this.btnchangeWE.Visible = false;
            this.btnchangeWE.Click += new System.EventHandler(this.btnchangeWE_Click);
            // 
            // dtp_work_experrience_finish
            // 
            this.dtp_work_experrience_finish.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_work_experrience_finish.Location = new System.Drawing.Point(166, 146);
            this.dtp_work_experrience_finish.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_work_experrience_finish.Name = "dtp_work_experrience_finish";
            this.dtp_work_experrience_finish.Size = new System.Drawing.Size(408, 27);
            this.dtp_work_experrience_finish.TabIndex = 39;
            // 
            // dtp_work_experrience_start
            // 
            this.dtp_work_experrience_start.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_work_experrience_start.Location = new System.Drawing.Point(167, 110);
            this.dtp_work_experrience_start.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_work_experrience_start.Name = "dtp_work_experrience_start";
            this.dtp_work_experrience_start.Size = new System.Drawing.Size(407, 27);
            this.dtp_work_experrience_start.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(36, 78);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 18);
            this.label17.TabIndex = 34;
            this.label17.Text = "POSITION:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(37, 153);
            this.label20.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(102, 18);
            this.label20.TabIndex = 38;
            this.label20.Text = "FINISH DATE:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(36, 41);
            this.label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(123, 18);
            this.label18.TabIndex = 35;
            this.label18.Text = "ORGANIZATION:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(36, 117);
            this.label19.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 18);
            this.label19.TabIndex = 37;
            this.label19.Text = "START DATE:";
            // 
            // txtOrganization
            // 
            this.txtOrganization.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrganization.Location = new System.Drawing.Point(167, 37);
            this.txtOrganization.Margin = new System.Windows.Forms.Padding(5);
            this.txtOrganization.Name = "txtOrganization";
            this.txtOrganization.Size = new System.Drawing.Size(407, 27);
            this.txtOrganization.TabIndex = 31;
            // 
            // txtPosition
            // 
            this.txtPosition.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosition.Location = new System.Drawing.Point(167, 74);
            this.txtPosition.Margin = new System.Windows.Forms.Padding(5);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(407, 27);
            this.txtPosition.TabIndex = 36;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnaddQuali);
            this.groupBox2.Controls.Add(this.btnremoveQuali);
            this.groupBox2.Controls.Add(this.dgvqualifications);
            this.groupBox2.Controls.Add(this.txtQualification);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(29, 66);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1235, 251);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "QUALIFICATIONS";
            // 
            // btnaddQuali
            // 
            this.btnaddQuali.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnaddQuali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnaddQuali.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddQuali.Location = new System.Drawing.Point(177, 192);
            this.btnaddQuali.Margin = new System.Windows.Forms.Padding(4);
            this.btnaddQuali.Name = "btnaddQuali";
            this.btnaddQuali.Size = new System.Drawing.Size(129, 38);
            this.btnaddQuali.TabIndex = 42;
            this.btnaddQuali.Text = "ADD";
            this.btnaddQuali.UseVisualStyleBackColor = false;
            this.btnaddQuali.Click += new System.EventHandler(this.btnaddQuali_Click);
            // 
            // btnremoveQuali
            // 
            this.btnremoveQuali.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnremoveQuali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnremoveQuali.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremoveQuali.Location = new System.Drawing.Point(314, 192);
            this.btnremoveQuali.Margin = new System.Windows.Forms.Padding(4);
            this.btnremoveQuali.Name = "btnremoveQuali";
            this.btnremoveQuali.Size = new System.Drawing.Size(128, 38);
            this.btnremoveQuali.TabIndex = 41;
            this.btnremoveQuali.Text = "REMOVE";
            this.btnremoveQuali.UseVisualStyleBackColor = false;
            this.btnremoveQuali.Click += new System.EventHandler(this.btnremoveQuali_Click);
            // 
            // btnchangeQuali
            // 
            this.btnchangeQuali.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnchangeQuali.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnchangeQuali.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchangeQuali.Location = new System.Drawing.Point(1014, 16);
            this.btnchangeQuali.Margin = new System.Windows.Forms.Padding(4);
            this.btnchangeQuali.Name = "btnchangeQuali";
            this.btnchangeQuali.Size = new System.Drawing.Size(129, 38);
            this.btnchangeQuali.TabIndex = 40;
            this.btnchangeQuali.Text = "CHANGE";
            this.btnchangeQuali.UseVisualStyleBackColor = false;
            this.btnchangeQuali.Visible = false;
            this.btnchangeQuali.Click += new System.EventHandler(this.btnchangeQuali_Click);
            // 
            // dgvqualifications
            // 
            this.dgvqualifications.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvqualifications.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvqualifications.BackgroundColor = System.Drawing.Color.MediumSpringGreen;
            this.dgvqualifications.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvqualifications.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column9,
            this.Column10});
            this.dgvqualifications.Location = new System.Drawing.Point(451, 59);
            this.dgvqualifications.Margin = new System.Windows.Forms.Padding(4);
            this.dgvqualifications.Name = "dgvqualifications";
            this.dgvqualifications.RowHeadersVisible = false;
            this.dgvqualifications.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvqualifications.Size = new System.Drawing.Size(751, 171);
            this.dgvqualifications.TabIndex = 0;
            this.dgvqualifications.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvqualification_CellContentDoubleClick);
            // 
            // Column9
            // 
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column9.DefaultCellStyle = dataGridViewCellStyle1;
            this.Column9.HeaderText = "Q_ID";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Column10.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column10.HeaderText = "DESCRIPTION";
            this.Column10.Name = "Column10";
            // 
            // txtQualification
            // 
            this.txtQualification.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQualification.Location = new System.Drawing.Point(39, 59);
            this.txtQualification.Margin = new System.Windows.Forms.Padding(5);
            this.txtQualification.Multiline = true;
            this.txtQualification.Name = "txtQualification";
            this.txtQualification.Size = new System.Drawing.Size(403, 121);
            this.txtQualification.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(33, 33);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(124, 18);
            this.label15.TabIndex = 33;
            this.label15.Text = "QUALIFICATION:";
            // 
            // dgvStaffList
            // 
            this.dgvStaffList.AllowUserToAddRows = false;
            this.dgvStaffList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvStaffList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStaffList.BackgroundColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStaffList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvStaffList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStaffList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Raleway", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStaffList.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvStaffList.Location = new System.Drawing.Point(535, 200);
            this.dgvStaffList.Margin = new System.Windows.Forms.Padding(4);
            this.dgvStaffList.Name = "dgvStaffList";
            this.dgvStaffList.ReadOnly = true;
            this.dgvStaffList.RowHeadersVisible = false;
            this.dgvStaffList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStaffList.Size = new System.Drawing.Size(783, 559);
            this.dgvStaffList.TabIndex = 39;
            this.dgvStaffList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStaffList_CellContentClick);
            this.dgvStaffList.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStaffList_CellContentDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Staff Number";
            this.Column1.MinimumWidth = 10;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Firstname";
            this.Column2.MinimumWidth = 20;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Lastname";
            this.Column3.MinimumWidth = 20;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Address";
            this.Column4.MinimumWidth = 20;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Telephone No";
            this.Column5.MinimumWidth = 10;
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Birthdate";
            this.Column6.MinimumWidth = 10;
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Sex";
            this.Column7.MinimumWidth = 7;
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "NIN";
            this.Column8.MinimumWidth = 10;
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Position";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Workshift";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Salary";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Employment Type";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            // 
            // Column20
            // 
            this.Column20.HeaderText = "Date Assigned";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.txtNIN);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.cbsex);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.dpbirthdate);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txttelnumber);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtaddress);
            this.groupBox1.Controls.Add(this.txtlastname);
            this.groupBox1.Controls.Add(this.txtfirstname);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtstaffnumber);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 138);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(500, 565);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "STAFF INFORMATION";
            // 
            // txtNIN
            // 
            this.txtNIN.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIN.Location = new System.Drawing.Point(29, 384);
            this.txtNIN.Margin = new System.Windows.Forms.Padding(5);
            this.txtNIN.Name = "txtNIN";
            this.txtNIN.Size = new System.Drawing.Size(439, 26);
            this.txtNIN.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(25, 362);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(247, 18);
            this.label10.TabIndex = 18;
            this.label10.Text = "NATIONAL INSURANCE NUMBER:";
            // 
            // cbsex
            // 
            this.cbsex.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbsex.FormattingEnabled = true;
            this.cbsex.Location = new System.Drawing.Point(287, 308);
            this.cbsex.Margin = new System.Windows.Forms.Padding(4);
            this.cbsex.Name = "cbsex";
            this.cbsex.Size = new System.Drawing.Size(181, 26);
            this.cbsex.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 311);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 18);
            this.label9.TabIndex = 16;
            this.label9.Text = "SEX:";
            // 
            // dpbirthdate
            // 
            this.dpbirthdate.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dpbirthdate.Location = new System.Drawing.Point(209, 273);
            this.dpbirthdate.Margin = new System.Windows.Forms.Padding(4);
            this.dpbirthdate.Name = "dpbirthdate";
            this.dpbirthdate.Size = new System.Drawing.Size(259, 26);
            this.dpbirthdate.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 281);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "BIRTH DATE:";
            // 
            // txttelnumber
            // 
            this.txttelnumber.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttelnumber.Location = new System.Drawing.Point(209, 238);
            this.txttelnumber.Margin = new System.Windows.Forms.Padding(5);
            this.txttelnumber.Name = "txttelnumber";
            this.txttelnumber.Size = new System.Drawing.Size(259, 26);
            this.txttelnumber.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 241);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 18);
            this.label7.TabIndex = 12;
            this.label7.Text = "TELEPHONE NUMBER:";
            // 
            // txtaddress
            // 
            this.txtaddress.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.Location = new System.Drawing.Point(209, 146);
            this.txtaddress.Margin = new System.Windows.Forms.Padding(5);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(259, 80);
            this.txtaddress.TabIndex = 11;
            // 
            // txtlastname
            // 
            this.txtlastname.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlastname.Location = new System.Drawing.Point(209, 110);
            this.txtlastname.Margin = new System.Windows.Forms.Padding(5);
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(259, 26);
            this.txtlastname.TabIndex = 10;
            // 
            // txtfirstname
            // 
            this.txtfirstname.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstname.Location = new System.Drawing.Point(209, 79);
            this.txtfirstname.Margin = new System.Windows.Forms.Padding(5);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(259, 26);
            this.txtfirstname.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 150);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 8;
            this.label6.Text = "ADDRESS:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 113);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 18);
            this.label5.TabIndex = 7;
            this.label5.Text = "LAST NAME:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 82);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "FIRST NAME:";
            // 
            // txtstaffnumber
            // 
            this.txtstaffnumber.Enabled = false;
            this.txtstaffnumber.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstaffnumber.Location = new System.Drawing.Point(209, 36);
            this.txtstaffnumber.Margin = new System.Windows.Forms.Padding(5);
            this.txtstaffnumber.Name = "txtstaffnumber";
            this.txtstaffnumber.Size = new System.Drawing.Size(259, 26);
            this.txtstaffnumber.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "STAFF NUMBER:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnUpdate.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnUpdate.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(16, 710);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(121, 49);
            this.btnUpdate.TabIndex = 42;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnPromoteDemote
            // 
            this.btnPromoteDemote.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPromoteDemote.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnPromoteDemote.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPromoteDemote.Location = new System.Drawing.Point(145, 711);
            this.btnPromoteDemote.Margin = new System.Windows.Forms.Padding(4);
            this.btnPromoteDemote.Name = "btnPromoteDemote";
            this.btnPromoteDemote.Size = new System.Drawing.Size(184, 49);
            this.btnPromoteDemote.TabIndex = 43;
            this.btnPromoteDemote.Text = "PROMOTE/DEMOTE";
            this.btnPromoteDemote.UseVisualStyleBackColor = false;
            this.btnPromoteDemote.Click += new System.EventHandler(this.btnPromoteDemote_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(531, 138);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(164, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Staff Master List:";
            // 
            // btnemployeebg
            // 
            this.btnemployeebg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnemployeebg.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnemployeebg.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnemployeebg.Location = new System.Drawing.Point(337, 711);
            this.btnemployeebg.Margin = new System.Windows.Forms.Padding(4);
            this.btnemployeebg.Name = "btnemployeebg";
            this.btnemployeebg.Size = new System.Drawing.Size(179, 49);
            this.btnemployeebg.TabIndex = 44;
            this.btnemployeebg.Text = "EMPLOYEE BACKGROUND";
            this.btnemployeebg.UseVisualStyleBackColor = false;
            this.btnemployeebg.Click += new System.EventHandler(this.btnemployeebg_Click);
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.Location = new System.Drawing.Point(535, 163);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(447, 30);
            this.tb_search.TabIndex = 45;
            // 
            // btn_search
            // 
            this.btn_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_search.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(1213, 162);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(105, 32);
            this.btn_search.TabIndex = 46;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // cb_search_filter
            // 
            this.cb_search_filter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_search_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_search_filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_search_filter.FormattingEnabled = true;
            this.cb_search_filter.Items.AddRange(new object[] {
            "Search By Name",
            "Search By Qualification",
            "Search By Experience"});
            this.cb_search_filter.Location = new System.Drawing.Point(988, 163);
            this.cb_search_filter.Name = "cb_search_filter";
            this.cb_search_filter.Size = new System.Drawing.Size(218, 30);
            this.cb_search_filter.TabIndex = 21;
            // 
            // StaffManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(1331, 772);
            this.Controls.Add(this.pnlEmployeeBG);
            this.Controls.Add(this.tb_search);
            this.Controls.Add(this.btnemployeebg);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnPromoteDemote);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgvStaffList);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.cb_search_filter);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "StaffManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "STAFF MANAGEMENT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.StaffManagement_FormClosed);
            this.Load += new System.EventHandler(this.StaffManagement_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlEmployeeBG.ResumeLayout(false);
            this.pnlEmployeeBG.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvworkexperiences)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvqualifications)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaffList)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvStaffList;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtNIN;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbsex;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dpbirthdate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txttelnumber;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtstaffnumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnPromoteDemote;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnemployeebg;
        private System.Windows.Forms.Panel pnlEmployeeBG;
        private System.Windows.Forms.DataGridView dgvqualifications;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvworkexperiences;
        private System.Windows.Forms.DateTimePicker dtp_work_experrience_finish;
        private System.Windows.Forms.DateTimePicker dtp_work_experrience_start;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtOrganization;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtQualification;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnaddWE;
        private System.Windows.Forms.Button btnremoveWE;
        private System.Windows.Forms.Button btnchangeWE;
        private System.Windows.Forms.Button btnaddQuali;
        private System.Windows.Forms.Button btnremoveQuali;
        private System.Windows.Forms.Button btnchangeQuali;
        private System.Windows.Forms.Label lblEmpName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.ComboBox cb_search_filter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
    }
}