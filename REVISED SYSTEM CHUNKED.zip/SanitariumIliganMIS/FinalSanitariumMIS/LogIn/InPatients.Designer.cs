﻿namespace LogIn
{
    partial class InPatients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_close_pick_doctor = new System.Windows.Forms.Panel();
            this.btn_Select_Doctor = new System.Windows.Forms.Button();
            this.label_close_pick_doctor = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dgv_pick_doctor = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_view_waitlist = new System.Windows.Forms.Button();
            this.btnAdmitPatient = new System.Windows.Forms.Button();
            this.cb_ward_number = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lblDoctorId = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btn_assign_doctor = new System.Windows.Forms.Button();
            this.tbDoctor = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpDateExpected = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpDatePlaced = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_bed_no = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dgv_inpatient_list = new System.Windows.Forms.DataGridView();
            this.tbDurationInDays = new System.Windows.Forms.TextBox();
            this.dtpDateArrived = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.tbPatientId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbPatientNo = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.cb_search_filter = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.cb_show_discharged = new System.Windows.Forms.CheckBox();
            this.btn_discharge_patient = new System.Windows.Forms.Button();
            this.panel_waitlist = new System.Windows.Forms.Panel();
            this.btn_accomodate = new System.Windows.Forms.Button();
            this.label_close_wait_list = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.dgv_waitlist = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label16 = new System.Windows.Forms.Label();
            this.rtb_referred = new System.Windows.Forms.RichTextBox();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel_close_pick_doctor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pick_doctor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_inpatient_list)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panel_waitlist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_waitlist)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(-3, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1481, 123);
            this.panel1.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Raleway", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(15, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 31);
            this.label4.TabIndex = 7;
            this.label4.Text = "In-Patient Records";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Raleway", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(15, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(437, 44);
            this.label3.TabIndex = 6;
            this.label3.Text = "SANITARIUM HOSPITAL";
            // 
            // panel_close_pick_doctor
            // 
            this.panel_close_pick_doctor.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel_close_pick_doctor.Controls.Add(this.btn_Select_Doctor);
            this.panel_close_pick_doctor.Controls.Add(this.label_close_pick_doctor);
            this.panel_close_pick_doctor.Controls.Add(this.label12);
            this.panel_close_pick_doctor.Controls.Add(this.dgv_pick_doctor);
            this.panel_close_pick_doctor.Location = new System.Drawing.Point(540, 219);
            this.panel_close_pick_doctor.Margin = new System.Windows.Forms.Padding(4);
            this.panel_close_pick_doctor.Name = "panel_close_pick_doctor";
            this.panel_close_pick_doctor.Size = new System.Drawing.Size(903, 489);
            this.panel_close_pick_doctor.TabIndex = 95;
            this.panel_close_pick_doctor.Visible = false;
            // 
            // btn_Select_Doctor
            // 
            this.btn_Select_Doctor.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Select_Doctor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Select_Doctor.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Select_Doctor.Location = new System.Drawing.Point(733, 443);
            this.btn_Select_Doctor.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Select_Doctor.Name = "btn_Select_Doctor";
            this.btn_Select_Doctor.Size = new System.Drawing.Size(117, 36);
            this.btn_Select_Doctor.TabIndex = 97;
            this.btn_Select_Doctor.Text = "SELECT";
            this.btn_Select_Doctor.UseVisualStyleBackColor = false;
            this.btn_Select_Doctor.Click += new System.EventHandler(this.btn_Select_Doctor_Click);
            // 
            // label_close_pick_doctor
            // 
            this.label_close_pick_doctor.AutoSize = true;
            this.label_close_pick_doctor.Font = new System.Drawing.Font("Raleway", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_close_pick_doctor.Location = new System.Drawing.Point(749, 18);
            this.label_close_pick_doctor.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_close_pick_doctor.Name = "label_close_pick_doctor";
            this.label_close_pick_doctor.Size = new System.Drawing.Size(101, 31);
            this.label_close_pick_doctor.TabIndex = 87;
            this.label_close_pick_doctor.Text = "CLOSE";
            this.label_close_pick_doctor.Click += new System.EventHandler(this.label_close_pick_doctor_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Raleway", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(40, 18);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(157, 31);
            this.label12.TabIndex = 86;
            this.label12.Text = "Pick Doctor";
            // 
            // dgv_pick_doctor
            // 
            this.dgv_pick_doctor.AllowUserToAddRows = false;
            this.dgv_pick_doctor.AllowUserToResizeColumns = false;
            this.dgv_pick_doctor.BackgroundColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_pick_doctor.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_pick_doctor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pick_doctor.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_pick_doctor.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_pick_doctor.Location = new System.Drawing.Point(47, 60);
            this.dgv_pick_doctor.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_pick_doctor.Name = "dgv_pick_doctor";
            this.dgv_pick_doctor.RowHeadersVisible = false;
            this.dgv_pick_doctor.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_pick_doctor.Size = new System.Drawing.Size(803, 377);
            this.dgv_pick_doctor.TabIndex = 85;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Staff Number";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Firstname";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Lastname";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Address";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Tel. No.";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Brithdate";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Sex";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "NIN";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // btn_view_waitlist
            // 
            this.btn_view_waitlist.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_view_waitlist.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_view_waitlist.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_view_waitlist.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view_waitlist.Location = new System.Drawing.Point(269, 803);
            this.btn_view_waitlist.Margin = new System.Windows.Forms.Padding(4);
            this.btn_view_waitlist.Name = "btn_view_waitlist";
            this.btn_view_waitlist.Size = new System.Drawing.Size(240, 53);
            this.btn_view_waitlist.TabIndex = 94;
            this.btn_view_waitlist.Text = "VIEW WAITLIST";
            this.btn_view_waitlist.UseVisualStyleBackColor = false;
            this.btn_view_waitlist.Click += new System.EventHandler(this.btn_view_waitlist_Click);
            // 
            // btnAdmitPatient
            // 
            this.btnAdmitPatient.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdmitPatient.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnAdmitPatient.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdmitPatient.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmitPatient.Location = new System.Drawing.Point(18, 739);
            this.btnAdmitPatient.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdmitPatient.Name = "btnAdmitPatient";
            this.btnAdmitPatient.Size = new System.Drawing.Size(236, 53);
            this.btnAdmitPatient.TabIndex = 93;
            this.btnAdmitPatient.Text = "ADMIT PATIENT";
            this.btnAdmitPatient.UseVisualStyleBackColor = false;
            this.btnAdmitPatient.Click += new System.EventHandler(this.btnAdmitPatient_Click);
            // 
            // cb_ward_number
            // 
            this.cb_ward_number.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cb_ward_number.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_ward_number.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ward_number.FormattingEnabled = true;
            this.cb_ward_number.Location = new System.Drawing.Point(225, 116);
            this.cb_ward_number.Margin = new System.Windows.Forms.Padding(4);
            this.cb_ward_number.Name = "cb_ward_number";
            this.cb_ward_number.Size = new System.Drawing.Size(242, 26);
            this.cb_ward_number.TabIndex = 87;
            this.cb_ward_number.SelectedIndexChanged += new System.EventHandler(this.cb_ward_number_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(85, 119);
            this.label14.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(126, 18);
            this.label14.TabIndex = 86;
            this.label14.Text = "WARD NUMBER:";
            // 
            // lblDoctorId
            // 
            this.lblDoctorId.AutoSize = true;
            this.lblDoctorId.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoctorId.Location = new System.Drawing.Point(229, 391);
            this.lblDoctorId.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDoctorId.Name = "lblDoctorId";
            this.lblDoctorId.Size = new System.Drawing.Size(0, 18);
            this.lblDoctorId.TabIndex = 85;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(119, 392);
            this.label13.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 18);
            this.label13.TabIndex = 84;
            this.label13.Text = "DOCTOR ID:";
            // 
            // btn_assign_doctor
            // 
            this.btn_assign_doctor.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_assign_doctor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_assign_doctor.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_assign_doctor.Location = new System.Drawing.Point(224, 425);
            this.btn_assign_doctor.Margin = new System.Windows.Forms.Padding(4);
            this.btn_assign_doctor.Name = "btn_assign_doctor";
            this.btn_assign_doctor.Size = new System.Drawing.Size(245, 36);
            this.btn_assign_doctor.TabIndex = 82;
            this.btn_assign_doctor.Text = "ASSIGN A DOCTOR";
            this.btn_assign_doctor.UseVisualStyleBackColor = false;
            this.btn_assign_doctor.Click += new System.EventHandler(this.btn_assign_doctor_Click);
            // 
            // tbDoctor
            // 
            this.tbDoctor.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDoctor.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDoctor.Location = new System.Drawing.Point(224, 356);
            this.tbDoctor.Margin = new System.Windows.Forms.Padding(5);
            this.tbDoctor.Name = "tbDoctor";
            this.tbDoctor.ReadOnly = true;
            this.tbDoctor.Size = new System.Drawing.Size(243, 25);
            this.tbDoctor.TabIndex = 81;
            this.tbDoctor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(138, 359);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 18);
            this.label8.TabIndex = 80;
            this.label8.Text = "DOCTOR:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(134, 326);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 18);
            this.label7.TabIndex = 79;
            this.label7.Text = "(IN DAYS)";
            // 
            // dtpDateExpected
            // 
            this.dtpDateExpected.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dtpDateExpected.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateExpected.Location = new System.Drawing.Point(225, 265);
            this.dtpDateExpected.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDateExpected.Name = "dtpDateExpected";
            this.dtpDateExpected.Size = new System.Drawing.Size(242, 25);
            this.dtpDateExpected.TabIndex = 78;
            this.dtpDateExpected.ValueChanged += new System.EventHandler(this.dtpDateExpected_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 268);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(202, 18);
            this.label9.TabIndex = 77;
            this.label9.Text = "DATE EXPECTED TO LEAVE:";
            // 
            // dtpDatePlaced
            // 
            this.dtpDatePlaced.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dtpDatePlaced.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDatePlaced.Location = new System.Drawing.Point(225, 228);
            this.dtpDatePlaced.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDatePlaced.Name = "dtpDatePlaced";
            this.dtpDatePlaced.Size = new System.Drawing.Size(242, 25);
            this.dtpDatePlaced.TabIndex = 76;
            this.dtpDatePlaced.ValueChanged += new System.EventHandler(this.dtpDatePlaced_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 231);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 18);
            this.label2.TabIndex = 75;
            this.label2.Text = "DATE PLACED IN WARD:";
            // 
            // cb_bed_no
            // 
            this.cb_bed_no.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cb_bed_no.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_bed_no.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_bed_no.FormattingEnabled = true;
            this.cb_bed_no.Location = new System.Drawing.Point(225, 154);
            this.cb_bed_no.Margin = new System.Windows.Forms.Padding(4);
            this.cb_bed_no.Name = "cb_bed_no";
            this.cb_bed_no.Size = new System.Drawing.Size(242, 26);
            this.cb_bed_no.TabIndex = 74;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Raleway", 12F);
            this.label10.Location = new System.Drawing.Point(513, 136);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(247, 24);
            this.label10.TabIndex = 90;
            this.label10.Text = "IN-PATIENT MASTERLIST:";
            // 
            // dgv_inpatient_list
            // 
            this.dgv_inpatient_list.AllowUserToAddRows = false;
            this.dgv_inpatient_list.AllowUserToDeleteRows = false;
            this.dgv_inpatient_list.AllowUserToResizeColumns = false;
            this.dgv_inpatient_list.AllowUserToResizeRows = false;
            this.dgv_inpatient_list.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_inpatient_list.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgv_inpatient_list.BackgroundColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_inpatient_list.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_inpatient_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_inpatient_list.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_inpatient_list.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_inpatient_list.Location = new System.Drawing.Point(517, 202);
            this.dgv_inpatient_list.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_inpatient_list.MultiSelect = false;
            this.dgv_inpatient_list.Name = "dgv_inpatient_list";
            this.dgv_inpatient_list.ReadOnly = true;
            this.dgv_inpatient_list.RowHeadersVisible = false;
            this.dgv_inpatient_list.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_inpatient_list.Size = new System.Drawing.Size(948, 660);
            this.dgv_inpatient_list.TabIndex = 91;
            // 
            // tbDurationInDays
            // 
            this.tbDurationInDays.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDurationInDays.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDurationInDays.Location = new System.Drawing.Point(224, 301);
            this.tbDurationInDays.Margin = new System.Windows.Forms.Padding(5);
            this.tbDurationInDays.Name = "tbDurationInDays";
            this.tbDurationInDays.ReadOnly = true;
            this.tbDurationInDays.Size = new System.Drawing.Size(243, 25);
            this.tbDurationInDays.TabIndex = 68;
            this.tbDurationInDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtpDateArrived
            // 
            this.dtpDateArrived.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dtpDateArrived.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateArrived.Location = new System.Drawing.Point(225, 191);
            this.dtpDateArrived.Margin = new System.Windows.Forms.Padding(4);
            this.dtpDateArrived.Name = "dtpDateArrived";
            this.dtpDateArrived.Size = new System.Drawing.Size(242, 25);
            this.dtpDateArrived.TabIndex = 70;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(92, 195);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 18);
            this.label6.TabIndex = 69;
            this.label6.Text = "DATE ARRIVED:";
            // 
            // tbPatientId
            // 
            this.tbPatientId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbPatientId.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPatientId.Location = new System.Drawing.Point(224, 42);
            this.tbPatientId.Margin = new System.Windows.Forms.Padding(5);
            this.tbPatientId.Name = "tbPatientId";
            this.tbPatientId.Size = new System.Drawing.Size(243, 25);
            this.tbPatientId.TabIndex = 60;
            this.tbPatientId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(102, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 18);
            this.label1.TabIndex = 59;
            this.label1.Text = "IN PATIENT ID:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(72, 83);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(140, 18);
            this.label15.TabIndex = 56;
            this.label15.Text = "PATIENT NUMBER:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(101, 158);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 18);
            this.label11.TabIndex = 20;
            this.label11.Text = "BED NUMBER:";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.rtb_referred);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.cbPatientNo);
            this.groupBox2.Controls.Add(this.cb_ward_number);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.lblDoctorId);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.btn_assign_doctor);
            this.groupBox2.Controls.Add(this.tbDoctor);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.dtpDateExpected);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.dtpDatePlaced);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cb_bed_no);
            this.groupBox2.Controls.Add(this.dtpDateArrived);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tbDurationInDays);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tbPatientId);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(14, 136);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(488, 595);
            this.groupBox2.TabIndex = 92;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "IN PATIENT INFORMATION";
            // 
            // cbPatientNo
            // 
            this.cbPatientNo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbPatientNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPatientNo.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPatientNo.FormattingEnabled = true;
            this.cbPatientNo.Location = new System.Drawing.Point(224, 75);
            this.cbPatientNo.Margin = new System.Windows.Forms.Padding(4);
            this.cbPatientNo.Name = "cbPatientNo";
            this.cbPatientNo.Size = new System.Drawing.Size(242, 26);
            this.cbPatientNo.TabIndex = 88;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(44, 304);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 18);
            this.label5.TabIndex = 67;
            this.label5.Text = "EXPECTED DURATION:";
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.Location = new System.Drawing.Point(517, 165);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(613, 30);
            this.tb_search.TabIndex = 96;
            // 
            // btn_search
            // 
            this.btn_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_search.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(1360, 163);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(105, 32);
            this.btn_search.TabIndex = 97;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // cb_search_filter
            // 
            this.cb_search_filter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_search_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_search_filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_search_filter.FormattingEnabled = true;
            this.cb_search_filter.Items.AddRange(new object[] {
            "DOCTOR_FIRSTNAME",
            "DOCTOR_LASTNAME",
            "FIRSTNAME",
            "LASTNAME",
            "WARD_NUMBER",
            "WARD",
            "BED_ID",
            "DESCRIPTION",
            "PATIENT_NUMBER"});
            this.cb_search_filter.Location = new System.Drawing.Point(1136, 165);
            this.cb_search_filter.Name = "cb_search_filter";
            this.cb_search_filter.Size = new System.Drawing.Size(218, 30);
            this.cb_search_filter.TabIndex = 95;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(18, 803);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(236, 53);
            this.button2.TabIndex = 98;
            this.button2.Text = "ADD TO WAITLIST";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cb_show_discharged
            // 
            this.cb_show_discharged.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_show_discharged.AutoSize = true;
            this.cb_show_discharged.Font = new System.Drawing.Font("Raleway", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_show_discharged.Location = new System.Drawing.Point(1262, 136);
            this.cb_show_discharged.Name = "cb_show_discharged";
            this.cb_show_discharged.Size = new System.Drawing.Size(203, 20);
            this.cb_show_discharged.TabIndex = 99;
            this.cb_show_discharged.Text = "Show Discharged Records";
            this.cb_show_discharged.UseVisualStyleBackColor = true;
            // 
            // btn_discharge_patient
            // 
            this.btn_discharge_patient.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_discharge_patient.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_discharge_patient.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_discharge_patient.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_discharge_patient.Location = new System.Drawing.Point(269, 739);
            this.btn_discharge_patient.Margin = new System.Windows.Forms.Padding(4);
            this.btn_discharge_patient.Name = "btn_discharge_patient";
            this.btn_discharge_patient.Size = new System.Drawing.Size(236, 53);
            this.btn_discharge_patient.TabIndex = 100;
            this.btn_discharge_patient.Text = "DISCHARGE PATIENT";
            this.btn_discharge_patient.UseVisualStyleBackColor = false;
            this.btn_discharge_patient.Click += new System.EventHandler(this.btn_discharge_patient_Click);
            // 
            // panel_waitlist
            // 
            this.panel_waitlist.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel_waitlist.Controls.Add(this.btn_accomodate);
            this.panel_waitlist.Controls.Add(this.label_close_wait_list);
            this.panel_waitlist.Controls.Add(this.label17);
            this.panel_waitlist.Controls.Add(this.dgv_waitlist);
            this.panel_waitlist.Location = new System.Drawing.Point(562, 131);
            this.panel_waitlist.Margin = new System.Windows.Forms.Padding(4);
            this.panel_waitlist.Name = "panel_waitlist";
            this.panel_waitlist.Size = new System.Drawing.Size(903, 489);
            this.panel_waitlist.TabIndex = 98;
            this.panel_waitlist.Visible = false;
            // 
            // btn_accomodate
            // 
            this.btn_accomodate.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_accomodate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_accomodate.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_accomodate.Location = new System.Drawing.Point(671, 443);
            this.btn_accomodate.Margin = new System.Windows.Forms.Padding(4);
            this.btn_accomodate.Name = "btn_accomodate";
            this.btn_accomodate.Size = new System.Drawing.Size(179, 36);
            this.btn_accomodate.TabIndex = 97;
            this.btn_accomodate.Text = "ACCOMODATE";
            this.btn_accomodate.UseVisualStyleBackColor = false;
            this.btn_accomodate.Click += new System.EventHandler(this.btn_accomodate_Click);
            // 
            // label_close_wait_list
            // 
            this.label_close_wait_list.AutoSize = true;
            this.label_close_wait_list.Font = new System.Drawing.Font("Raleway", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_close_wait_list.Location = new System.Drawing.Point(749, 18);
            this.label_close_wait_list.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_close_wait_list.Name = "label_close_wait_list";
            this.label_close_wait_list.Size = new System.Drawing.Size(101, 31);
            this.label_close_wait_list.TabIndex = 87;
            this.label_close_wait_list.Text = "CLOSE";
            this.label_close_wait_list.Click += new System.EventHandler(this.label_close_wait_list_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Raleway", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(40, 18);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(161, 31);
            this.label17.TabIndex = 86;
            this.label17.Text = "Waiting List";
            // 
            // dgv_waitlist
            // 
            this.dgv_waitlist.AllowUserToAddRows = false;
            this.dgv_waitlist.AllowUserToResizeColumns = false;
            this.dgv_waitlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_waitlist.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgv_waitlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_waitlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.dgv_waitlist.Location = new System.Drawing.Point(47, 60);
            this.dgv_waitlist.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_waitlist.Name = "dgv_waitlist";
            this.dgv_waitlist.RowHeadersVisible = false;
            this.dgv_waitlist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_waitlist.Size = new System.Drawing.Size(803, 377);
            this.dgv_waitlist.TabIndex = 85;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Order No";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Patient Number";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Waiting for Ward";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Firstname";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Lastname";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "Contact No";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "Date Listed";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(72, 491);
            this.label16.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(135, 18);
            this.label16.TabIndex = 89;
            this.label16.Text = "REFERRED FROM:";
            // 
            // rtb_referred
            // 
            this.rtb_referred.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rtb_referred.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_referred.Location = new System.Drawing.Point(224, 487);
            this.rtb_referred.Name = "rtb_referred";
            this.rtb_referred.Size = new System.Drawing.Size(242, 96);
            this.rtb_referred.TabIndex = 90;
            this.rtb_referred.Text = "";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "In-Patient ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 123;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Patient ID Number";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 152;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Patient Firstname";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 145;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Patient Lastname";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 145;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Address";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 93;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Contact No";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 107;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Birthdate";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Sex";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 63;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Marital Status";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 119;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Doctor ID Number";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 151;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Doctor Firstname";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 144;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Doctor Lastname";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 144;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Ward Number";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 125;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Ward";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 74;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Ward Description";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 143;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Bed Number";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.Width = 117;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Bed Description";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.Width = 135;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Date Arrived";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.Width = 113;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Expected Duration";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.Width = 152;
            // 
            // Column20
            // 
            this.Column20.HeaderText = "Date Discharged";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Width = 139;
            // 
            // Column21
            // 
            this.Column21.HeaderText = "Referred From";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Width = 127;
            // 
            // InPatients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1478, 875);
            this.Controls.Add(this.panel_waitlist);
            this.Controls.Add(this.btn_discharge_patient);
            this.Controls.Add(this.panel_close_pick_doctor);
            this.Controls.Add(this.cb_show_discharged);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tb_search);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.cb_search_filter);
            this.Controls.Add(this.btn_view_waitlist);
            this.Controls.Add(this.btnAdmitPatient);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dgv_inpatient_list);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "InPatients";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IN-PATIENTS ADMISSION";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InPatients_FormClosing);
            this.Load += new System.EventHandler(this.InPatients_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_close_pick_doctor.ResumeLayout(false);
            this.panel_close_pick_doctor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pick_doctor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_inpatient_list)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel_waitlist.ResumeLayout(false);
            this.panel_waitlist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_waitlist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_view_waitlist;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_close_pick_doctor;
        private System.Windows.Forms.Button btn_Select_Doctor;
        private System.Windows.Forms.Label label_close_pick_doctor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgv_pick_doctor;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Button btnAdmitPatient;
        private System.Windows.Forms.ComboBox cb_ward_number;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblDoctorId;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_assign_doctor;
        private System.Windows.Forms.TextBox tbDoctor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpDateExpected;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpDatePlaced;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_bed_no;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgv_inpatient_list;
        private System.Windows.Forms.TextBox tbDurationInDays;
        private System.Windows.Forms.DateTimePicker dtpDateArrived;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbPatientId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.ComboBox cb_search_filter;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox cb_show_discharged;
        private System.Windows.Forms.Button btn_discharge_patient;
        private System.Windows.Forms.Panel panel_waitlist;
        private System.Windows.Forms.Button btn_accomodate;
        private System.Windows.Forms.Label label_close_wait_list;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView dgv_waitlist;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.ComboBox cbPatientNo;
        private System.Windows.Forms.RichTextBox rtb_referred;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
    }
}