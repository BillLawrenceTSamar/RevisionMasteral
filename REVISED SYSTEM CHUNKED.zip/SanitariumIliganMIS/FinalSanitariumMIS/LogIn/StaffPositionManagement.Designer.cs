﻿namespace LogIn
{
    partial class StaffPositionManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbSalaryPaymnetType = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cbworkshift = new System.Windows.Forms.ComboBox();
            this.txtfullname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpstartdate = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cbtypeemp = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbposition = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvpositionheld = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnchangepos = new System.Windows.Forms.Button();
            this.btnupdatepos = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvpositionheld)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbSalaryPaymnetType);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.cbworkshift);
            this.groupBox2.Controls.Add(this.txtfullname);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.dtpstartdate);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.cbtypeemp);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.cbposition);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(15, 117);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(384, 235);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "EMPLOYMENT DETAILS";
            // 
            // cbSalaryPaymnetType
            // 
            this.cbSalaryPaymnetType.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSalaryPaymnetType.FormattingEnabled = true;
            this.cbSalaryPaymnetType.Location = new System.Drawing.Point(189, 110);
            this.cbSalaryPaymnetType.Name = "cbSalaryPaymnetType";
            this.cbSalaryPaymnetType.Size = new System.Drawing.Size(179, 22);
            this.cbSalaryPaymnetType.TabIndex = 60;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(21, 113);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(122, 14);
            this.label24.TabIndex = 59;
            this.label24.Text = "SALARY PAYMENT TYPE";
            // 
            // cbworkshift
            // 
            this.cbworkshift.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbworkshift.FormattingEnabled = true;
            this.cbworkshift.Location = new System.Drawing.Point(189, 82);
            this.cbworkshift.Name = "cbworkshift";
            this.cbworkshift.Size = new System.Drawing.Size(179, 22);
            this.cbworkshift.TabIndex = 58;
            // 
            // txtfullname
            // 
            this.txtfullname.Enabled = false;
            this.txtfullname.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfullname.Location = new System.Drawing.Point(189, 24);
            this.txtfullname.Margin = new System.Windows.Forms.Padding(4);
            this.txtfullname.Name = "txtfullname";
            this.txtfullname.Size = new System.Drawing.Size(179, 22);
            this.txtfullname.TabIndex = 57;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(21, 27);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 14);
            this.label15.TabIndex = 56;
            this.label15.Text = "STAFF NAME:";
            // 
            // dtpstartdate
            // 
            this.dtpstartdate.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpstartdate.Location = new System.Drawing.Point(189, 189);
            this.dtpstartdate.Name = "dtpstartdate";
            this.dtpstartdate.Size = new System.Drawing.Size(179, 22);
            this.dtpstartdate.TabIndex = 34;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(21, 195);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 14);
            this.label23.TabIndex = 35;
            this.label23.Text = "START DATE:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(21, 85);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 14);
            this.label13.TabIndex = 24;
            this.label13.Text = "WORK SHIFT:";
            // 
            // cbtypeemp
            // 
            this.cbtypeemp.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbtypeemp.FormattingEnabled = true;
            this.cbtypeemp.Location = new System.Drawing.Point(189, 138);
            this.cbtypeemp.Name = "cbtypeemp";
            this.cbtypeemp.Size = new System.Drawing.Size(179, 22);
            this.cbtypeemp.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(21, 141);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 14);
            this.label12.TabIndex = 22;
            this.label12.Text = "TYPE OF EMPLOYMENT:";
            // 
            // cbposition
            // 
            this.cbposition.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbposition.FormattingEnabled = true;
            this.cbposition.Location = new System.Drawing.Point(189, 53);
            this.cbposition.Name = "cbposition";
            this.cbposition.Size = new System.Drawing.Size(179, 22);
            this.cbposition.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(21, 56);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 14);
            this.label11.TabIndex = 20;
            this.label11.Text = "POSITION:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1104, 100);
            this.panel1.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 49);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(382, 33);
            this.label4.TabIndex = 7;
            this.label4.Text = "Management Information System";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(355, 42);
            this.label3.TabIndex = 6;
            this.label3.Text = "SANITARIUM HOSPITAL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(417, 112);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 19);
            this.label1.TabIndex = 54;
            this.label1.Text = "Staff Position History:";
            // 
            // dgvpositionheld
            // 
            this.dgvpositionheld.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvpositionheld.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgvpositionheld.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvpositionheld.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvpositionheld.Location = new System.Drawing.Point(421, 134);
            this.dgvpositionheld.Name = "dgvpositionheld";
            this.dgvpositionheld.RowHeadersVisible = false;
            this.dgvpositionheld.Size = new System.Drawing.Size(660, 259);
            this.dgvpositionheld.TabIndex = 55;
            this.dgvpositionheld.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvpositions_CellContentDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "POSHELD_ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "POSITION";
            this.Column2.Name = "Column2";
            this.Column2.Width = 83;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "WORKSHIFT";
            this.Column3.Name = "Column3";
            this.Column3.Width = 97;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "SALARY";
            this.Column4.Name = "Column4";
            this.Column4.Width = 74;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "EMPLOYMENT_TYPE";
            this.Column5.Name = "Column5";
            this.Column5.Width = 141;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "DATE_START";
            this.Column6.Name = "Column6";
            this.Column6.Width = 103;
            // 
            // btnchangepos
            // 
            this.btnchangepos.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnchangepos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnchangepos.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnchangepos.Location = new System.Drawing.Point(219, 358);
            this.btnchangepos.Name = "btnchangepos";
            this.btnchangepos.Size = new System.Drawing.Size(180, 35);
            this.btnchangepos.TabIndex = 56;
            this.btnchangepos.Text = "PROMOTE/DEMOTE";
            this.btnchangepos.UseVisualStyleBackColor = false;
            this.btnchangepos.Click += new System.EventHandler(this.btnchangepos_Click);
            // 
            // btnupdatepos
            // 
            this.btnupdatepos.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnupdatepos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupdatepos.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatepos.Location = new System.Drawing.Point(15, 358);
            this.btnupdatepos.Name = "btnupdatepos";
            this.btnupdatepos.Size = new System.Drawing.Size(198, 35);
            this.btnupdatepos.TabIndex = 58;
            this.btnupdatepos.Text = "UPDATE CURRENT POSITION";
            this.btnupdatepos.UseVisualStyleBackColor = false;
            this.btnupdatepos.Click += new System.EventHandler(this.btnupdatepos_Click);
            // 
            // StaffPositionManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(1104, 410);
            this.Controls.Add(this.btnupdatepos);
            this.Controls.Add(this.btnchangepos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvpositionheld);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Name = "StaffPositionManagement";
            this.Text = "STAFF-POSITION MANAGEMENT";
            this.Load += new System.EventHandler(this.StaffPositionManagement_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvpositionheld)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dtpstartdate;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbtypeemp;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbposition;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvpositionheld;
        private System.Windows.Forms.TextBox txtfullname;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cbworkshift;
        private System.Windows.Forms.ComboBox cbSalaryPaymnetType;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnchangepos;
        private System.Windows.Forms.Button btnupdatepos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
    }
}