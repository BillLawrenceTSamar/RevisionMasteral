﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogIn
{
    public partial class MedDirMainMenu : Form
    {
        public MedDirMainMenu()
        {
            InitializeComponent();
        }

        private void btnpatientregistration_Click(object sender, EventArgs e)
        {
            PatientRegistration frmPR = new PatientRegistration();
            frmPR.Show();
            this.Dispose();
        }

        private void btnhumanresource_Click(object sender, EventArgs e)
        {
            HRMainMenu frmHR = new HRMainMenu();
            frmHR.Show();
            this.Dispose();
        }

        private void btnrequisitions_Click(object sender, EventArgs e)
        {
            Requisitions frmReq = new Requisitions();
            frmReq.Show();
            this.Dispose();
        }

        private void btnappointments_Click(object sender, EventArgs e)
        {
            Appointments1 frmAppoint = new Appointments1();
            frmAppoint.Show();
            this.Dispose();
        }

        private void btninventory_Click(object sender, EventArgs e)
        {
            InventoryManagement frmIM = new InventoryManagement();
            frmIM.Show();
            this.Dispose();
        }

        private void btnrooms_Click(object sender, EventArgs e)
        {
            RoomManagement frmRM = new RoomManagement();
            frmRM.Show();
            this.Dispose();
        }

        private void MedDirMainMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Program.LoginScreen.Show();
            //this.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StaffManagement frmSM = new StaffManagement();
            frmSM.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            new StaffWardAllocation().ShowDialog();
            this.Dispose();
            this.Dispose();
        }

        private void btn_StaffRegistration_Click(object sender, EventArgs e)
        {
            StaffRegistration sr = new StaffRegistration();
            sr.ShowDialog();
            this.Dispose();
        }

        private void btn_inpatient_Click(object sender, EventArgs e)
        {
            InPatients x = new InPatients();
            x.Show();
            this.Dispose();
        }

        private void btn_medications_Click(object sender, EventArgs e)
        {
            new MedicationRequisitions().Show();
            this.Dispose();
        }

        private void MedDirMainMenu_Load(object sender, EventArgs e)
        {
            if(Program.SESSION["ACCOUNT_TYPE"] == "1") // OJT
            {
                lbl_position.Text = "Trainee";
                btnpatientregistration.Enabled = true;
                return;
            }

            if (Program.SESSION["ACCOUNT_TYPE"] == "2") // NURSE
            {
                lbl_position.Text = "Charge Nurse";
                btnpatientregistration.Enabled = true;
                btnappointments.Enabled = true;
                btn_inpatient.Enabled = true;
                btn_medications.Enabled = true;
                btnrooms.Enabled = true;
                btninventory.Enabled = true;
                btnrequisitions.Enabled = true;
                return;
            }

            if (Program.SESSION["ACCOUNT_TYPE"] == "3") // IN-DOCTOR
            {
                lbl_position.Text = "In Doctor";
                btnpatientregistration.Enabled = true;
                return;
            }

            if (Program.SESSION["ACCOUNT_TYPE"] == "4") // OUT-DOCTOR
            {
                lbl_position.Text = "Out Doctor";
                btnpatientregistration.Enabled = true;
                return;
            }

            if (Program.SESSION["ACCOUNT_TYPE"] == "5") // PERSONNEL OFFICER
            {
                lbl_position.Text = "Personnel Officer";
                btnpatientregistration.Enabled = true;
                btn_StaffRegistration.Enabled = true;
                btn_StaffRecords.Enabled = true;
                btn_staff_ward_alloc.Enabled = true;
                btn_salary_maintenance.Enabled = true;
                btn_position_maintenance.Enabled = true;

                return;
            }

            if (Program.SESSION["ACCOUNT_TYPE"] == "6") // MEDICAL DIRECTOR
            {
                lbl_position.Text = "Medical Director";
                btnpatientregistration.Enabled = true;
                btninventory.Enabled = true;
                btnrequisitions.Enabled = true;
                btn_inpatient.Enabled = true;
                btnappointments.Enabled = true;

                return;
            }

            if (Program.SESSION["ACCOUNT_TYPE"] == "7") // SUPER
            {
                lbl_position.Text = "Super User";
                btnpatientregistration.Enabled = true;
                btn_StaffRegistration.Enabled = true;
                btn_StaffRecords.Enabled = true;
                btn_staff_ward_alloc.Enabled = true;
                btn_salary_maintenance.Enabled = true;
                btn_position_maintenance.Enabled = true;
                btnpatientregistration.Enabled = true;
                btnappointments.Enabled = true;
                btn_inpatient.Enabled = true;
                btn_medications.Enabled = true;
                btnrooms.Enabled = true;
                btninventory.Enabled = true;
                btnrequisitions.Enabled = true;

                return;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_time.Text = System.DateTime.Now.TimeOfDay.Hours.ToString() + ":" + System.DateTime.Now.TimeOfDay.Minutes.ToString() + ":" + System.DateTime.Now.TimeOfDay.Seconds.ToString();
        }
    }
}
