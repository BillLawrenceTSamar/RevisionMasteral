﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBM.Data.DB2;

namespace LogIn
{
    public partial class InPatients : Form
    {
        private FinalSanitariumMIS.Helpers.DatabaseHelper DB;
        private List<String[]> Rooms;
        private List<String[]> Beds;

        public InPatients()
        {
            InitializeComponent();
            PopulateRoomComboBox();
            PopulatePatientMasterList();
        }

        private String[] findMatch(List<String[]> target_string_list, int target_index, String key)
        {
            foreach (String[] row in target_string_list)
            {
                if (row[target_index] == key)
                {
                    return row;
                }
            }

            return null;
        }

        private void PopulateDotorMasterList()
        {
            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM staff ORDER BY firstname DESC");

            dgv_pick_doctor.Rows.Clear();

            while (rs.Read())
            {
                Object[] d = new Object[8];

                d[0] = rs.GetString(0);
                d[1] = rs.GetString(1);
                d[2] = rs.GetString(2);
                d[3] = rs.GetString(3);
                d[4] = rs.GetString(4);
                d[5] = rs.GetString(5);
                d[6] = rs.GetString(6);
                d[7] = rs.GetString(7);

                dgv_pick_doctor.Rows.Add(d);
            }
        }

        private void PopulatePatientMasterList()
        {
            String Condition = " WHERE DATE_LEFT IS NULL ";

            String[] filters = new string[] {
                "DOCTOR_FIRSTNAME",
                "DOCTOR_LASTNAME",
                "FIRSTNAME",
                "LASTNAME",
                "WARD_NUMBER",
                "WARD",
                "BED_ID",
                "DESCRIPTION",
                "PATIENT_NUMBER"
            };

            if (cb_show_discharged.Checked)
            {
                Condition = " WHERE DATE_LEFT IS NOT NULL ";
            }

            if(tb_search.Text != "" && cb_show_discharged.Checked)
            {
                if (cb_search_filter.Text == "PATIENT_NUMBER")
                {
                    Condition = Condition + " AND " + filters[cb_search_filter.SelectedIndex] + " = " + tb_search.Text;
                }
                else
                {
                    Condition = Condition + " AND " + filters[cb_search_filter.SelectedIndex] + " LIKE '" + tb_search.Text + "%'";
                }
            }

            if (tb_search.Text != "" && !cb_show_discharged.Checked)
            {
                if (cb_search_filter.Text == "PATIENT_NUMBER")
                {
                    Condition = Condition + " AND " + filters[cb_search_filter.SelectedIndex] + " = " + tb_search.Text;
                }
                else
                {
                    Condition = Condition + " AND " + filters[cb_search_filter.SelectedIndex] + " LIKE '" + tb_search.Text + "%'";
                }
                
            }

            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();
            // MessageBox.Show("SELECT * FROM (SELECT INPATIENTRECORD.INPATIENT_ID, INPATIENTRECORD.STAFF_NUMBER, STAFF.FIRSTNAME AS DOCTOR_FIRSTNAME, STAFF.LASTNAME AS DOCTOR_LASTNAME, INPATIENTRECORD.WARD_NUMBER, WARD.NAME AS WARD, WARD.DESCRIPTION AS WARD_DESCRIPTION, INPATIENTRECORD.PATIENT_NUMBER, PATIENT.FIRSTNAME, PATIENT.LASTNAME, PATIENT.ADDRESS, PATIENT.TELNUMBER, PATIENT.BIRTHDATE, PATIENT.SEX, PATIENT.MARITAL_STATUS, INPATIENTRECORD.BED_ID, BED.DESCRIPTION, INPATIENTRECORD.DATE_ARRIVED, INPATIENTRECORD.EXPECTED_DURATION, INPATIENTRECORD.DATE_LEFT, INPATIENTRECORD.REFERREDFROM FROM INPATIENTRECORD, STAFF, PATIENT, WARD, BED WHERE INPATIENTRECORD.STAFF_NUMBER = STAFF.STAFF_NUMBER AND INPATIENTRECORD.PATIENT_NUMBER = PATIENT.PATIENT_NUMBER AND INPATIENTRECORD.WARD_NUMBER = WARD.WARD_NUMBER AND INPATIENTRECORD.BED_ID = BED.BED_ID AND INPATIENTRECORD.WARD_NUMBER = BED.WARD_NUMBER) AS A " + Condition);
            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM (SELECT INPATIENTRECORD.INPATIENT_ID, INPATIENTRECORD.STAFF_NUMBER, STAFF.FIRSTNAME AS DOCTOR_FIRSTNAME, STAFF.LASTNAME AS DOCTOR_LASTNAME, INPATIENTRECORD.WARD_NUMBER, WARD.NAME AS WARD, WARD.DESCRIPTION AS WARD_DESCRIPTION, INPATIENTRECORD.PATIENT_NUMBER, PATIENT.FIRSTNAME, PATIENT.LASTNAME, PATIENT.ADDRESS, PATIENT.TELNUMBER, PATIENT.BIRTHDATE, PATIENT.SEX, PATIENT.MARITAL_STATUS, INPATIENTRECORD.BED_ID, BED.DESCRIPTION, INPATIENTRECORD.DATE_ARRIVED, INPATIENTRECORD.EXPECTED_DURATION, INPATIENTRECORD.DATE_LEFT, INPATIENTRECORD.REFERREDFROM FROM INPATIENTRECORD, STAFF, PATIENT, WARD, BED WHERE INPATIENTRECORD.STAFF_NUMBER = STAFF.STAFF_NUMBER AND INPATIENTRECORD.PATIENT_NUMBER = PATIENT.PATIENT_NUMBER AND INPATIENTRECORD.WARD_NUMBER = WARD.WARD_NUMBER AND INPATIENTRECORD.BED_ID = BED.BED_ID AND INPATIENTRECORD.WARD_NUMBER = BED.WARD_NUMBER) AS A " + Condition);

            dgv_inpatient_list.Rows.Clear();

            while (rs.Read())
            {
                String[] d = new String[] {
                    rs.GetValue(0).ToString(),
                    rs.GetValue(7).ToString(),
                    rs.GetValue(8).ToString(),
                    rs.GetValue(9).ToString(),
                    rs.GetValue(10).ToString(),
                    rs.GetValue(11).ToString(),
                    rs.GetValue(12).ToString(),
                    rs.GetValue(13).ToString(),
                    rs.GetValue(14).ToString(),
                    rs.GetValue(1).ToString(),
                    rs.GetValue(2).ToString(),
                    rs.GetValue(3).ToString(),
                    rs.GetValue(4).ToString(),
                    rs.GetValue(5).ToString(),
                    rs.GetValue(6).ToString(),
                    rs.GetValue(15).ToString(),
                    rs.GetValue(16).ToString(),
                    rs.GetValue(17).ToString(),
                    rs.GetValue(18).ToString(),
                    rs.GetValue(19).ToString(),
                    rs.GetValue(20).ToString()
                };

                dgv_inpatient_list.Rows.Add(d);
            }
        }

        private void PopulateRoomComboBox()
        {
            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM ward");

            cb_ward_number.Items.Clear();
            Rooms = new List<string[]>();

            while (rs.Read())
            {
                Rooms.Add(new String[] {
                    rs.GetString(0),
                    rs.GetString(1)
                });

                cb_ward_number.Items.Add(rs.GetString(1));
            }
        }

        private void InPatients_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show(null, "Close the In-Patients Form", "Confirm Action", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                MedDirMainMenu frmMD = new MedDirMainMenu();
                frmMD.Show();
                this.Dispose();
            }
        }

        private void btn_assign_doctor_Click(object sender, EventArgs e)
        {
            panel_close_pick_doctor.Show();
            PopulateDotorMasterList();
        }

        private void label_close_pick_doctor_Click(object sender, EventArgs e)
        {
            panel_close_pick_doctor.Hide();
        }

        private void btn_Select_Doctor_Click(object sender, EventArgs e)
        {
            tbDoctor.Text = dgv_pick_doctor.CurrentRow.Cells[1].Value.ToString() + " " + dgv_pick_doctor.CurrentRow.Cells[2].Value.ToString();
            lblDoctorId.Text = dgv_pick_doctor.CurrentRow.Cells[0].Value.ToString();
        }

        private void cb_bed_no_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cb_ward_number_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_ward_number.SelectedIndex < 0)
            {
                return;
            }

            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM bed WHERE AVAILABILITY = 'AVAILABLE' AND ward_number = '" + findMatch(Rooms, 1, cb_ward_number.SelectedItem.ToString())[0] + "'");

            cb_bed_no.Items.Clear();
            Beds = new List<string[]>();

            while (rs.Read())
            {
                Beds.Add(new String[] {
                    rs.GetString(0),
                    rs.GetString(1),
                    rs.GetString(2),
                    rs.GetString(3)
                });

                cb_bed_no.Items.Add(rs.GetString(3));
            }

            if (cb_bed_no.Items.Count < 1)
            {
                MessageBox.Show("No Beds In Room");
            }
        }

        private void dtpDatePlaced_ValueChanged(object sender, EventArgs e)
        {
            tbDurationInDays.Text = (DateTime.Parse(dtpDateExpected.Text).Date - DateTime.Parse(dtpDatePlaced.Text).Date).TotalDays.ToString();
        }

        private void dtpDateExpected_ValueChanged(object sender, EventArgs e)
        {
            tbDurationInDays.Text = (DateTime.Parse(dtpDateExpected.Text).Date - DateTime.Parse(dtpDatePlaced.Text).Date).TotalDays.ToString();
        }

        private void btnAdmitPatient_Click(object sender, EventArgs e)
        {
            if (tbPatientId.Text == "" || cbPatientNo.Text == "" || tbDoctor.Text == "")
            {
                MessageBox.Show("Please Fill-in all fields");
                return;
            }

            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();

            MessageBox.Show("INSERT INTO inpatientrecord VALUES (" + tbPatientId.Text + ",'" +
                lblDoctorId.Text + "','" + findMatch(Rooms, 1, cb_ward_number.Text)[0] + "','" + cbPatientNo.Text.Substring(0,cbPatientNo.Text.IndexOf('-')) + "','" + findMatch(Beds, 3, cb_bed_no.Text)[0] +
                "','" + DateTime.Parse(dtpDateArrived.Text).Date.ToString("M-dd-yyyy") +
                "'," + tbDurationInDays.Text + ",NULL,'" + rtb_referred.Text + "')");

            DB.Query("INSERT INTO inpatientrecord VALUES (" + tbPatientId.Text + ",'" +
                lblDoctorId.Text + "','" + findMatch(Rooms,1 ,cb_ward_number.Text)[0] + "','" + cbPatientNo.Text.Substring(0, cbPatientNo.Text.IndexOf('-')) + "','" + findMatch(Beds, 3, cb_bed_no.Text)[0] +
                "','" + DateTime.Parse(dtpDateArrived.Text).Date.ToString("M-dd-yyyy") +
                "'," + tbDurationInDays.Text + ",NULL,'" + rtb_referred.Text + "')");

            DB.Query("UPDATE BED SET AVAILABILITY = 'OCCUPIED' WHERE BED_ID = " + findMatch(Beds, 3, cb_bed_no.Text)[0] + " AND WARD_NUMBER = '" + findMatch(Rooms, 1, cb_ward_number.Text)[0] + "'");

            MessageBox.Show("Patient Admitted!");

            PopulatePatientMasterList();
            cb_ward_number.SelectedIndex = -1;
            cb_bed_no.Items.Clear();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            PopulatePatientMasterList();
        }

        private void btn_discharge_patient_Click(object sender, EventArgs e)
        {
            if(dgv_inpatient_list.CurrentRow == null)
            {
                MessageBox.Show("Select patient to discharge");
                return;
            }

            DB.Query("UPDATE INPATIENTRECORD SET DATE_LEFT = CURRENT_TIMESTAMP WHERE INPATIENT_ID = " + dgv_inpatient_list.CurrentRow.Cells[0].Value.ToString());

            DB.Query("UPDATE BED SET AVAILABILITY = 'AVAILABLE' WHERE BED_ID = " + dgv_inpatient_list.CurrentRow.Cells[15].Value.ToString() + " AND WARD_NUMBER = '" + dgv_inpatient_list.CurrentRow.Cells[12].Value.ToString() + "'");

            MessageBox.Show("Patient Marked as Discharged!");
            PopulatePatientMasterList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cbPatientNo.Text == "")
            {
                MessageBox.Show("Please Fill-in all fields");
                return;
            }

            DB.Query("INSERT INTO waitlist (patient_number, ward_number, date_arrived) VALUES (" + cbPatientNo.Text.Substring(0, cbPatientNo.Text.IndexOf('-')) + ",'" + findMatch(Rooms, 1, cb_ward_number.Text)[0] + "', CURRENT_TIMESTAMP)");

            MessageBox.Show("Patient Added To Waiting List!");
        }

        private void btn_view_waitlist_Click(object sender, EventArgs e)
        {
            DB2ResultSet rs = DB.QueryWithResultSet("SELECT WAITLIST.ORDERNUM, WAITLIST.PATIENT_NUMBER, WAITLIST.WARD_NUMBER, PATIENT.FIRSTNAME, PATIENT.LASTNAME, PATIENT.TELNUMBER, WAITLIST.DATE_ARRIVED FROM WAITLIST, PATIENT WHERE WAITLIST.PATIENT_NUMBER = PATIENT.PATIENT_NUMBER");

            dgv_waitlist.Rows.Clear();

            while (rs.Read())
            {
                dgv_waitlist.Rows.Add(new String[] {
                    rs.GetValue(0).ToString(),
                    rs.GetValue(1).ToString(),
                    rs.GetValue(2).ToString(),
                    rs.GetValue(3).ToString(),
                    rs.GetValue(4).ToString(),
                    rs.GetValue(5).ToString(),
                    rs.GetValue(6).ToString()
                });
            }

            panel_waitlist.Show();
        }

        private void label_close_wait_list_Click(object sender, EventArgs e)
        {
            panel_waitlist.Hide();
        }

        private void btn_accomodate_Click(object sender, EventArgs e)
        {
            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM bed WHERE AVAILABILITY = 'AVAILABLE' AND ward_number = '" + dgv_waitlist.CurrentRow.Cells[2].Value.ToString() + "'");

            List<string[]> s = new List<string[]>();

            while (rs.Read())
            {
                s.Add(new String[] {
                    rs.GetString(0),
                    rs.GetString(1),
                    rs.GetString(2),
                    rs.GetString(3)
                });
            }

            if (s.Count < 1)
            {
                MessageBox.Show("Ward is still full!");
                return;
            }
            else
            {
                DB.Query("DELETE FROM WAITLIST WHERE ORDERNUM = " + dgv_waitlist.CurrentRow.Cells[0].Value.ToString());
                MessageBox.Show("Ward has a vacancy! Please set Patient's assigned bed and doctor");

                foreach(String ss in cbPatientNo.Items)
                {
                    if(ss.Substring(0,ss.IndexOf('-')) == dgv_waitlist.CurrentRow.Cells[1].Value.ToString())
                    {
                        cbPatientNo.SelectedIndex = cbPatientNo.Items.IndexOf(ss);
                    }
                }

                cb_ward_number.SelectedItem = dgv_waitlist.CurrentRow.Cells[2].Value.ToString();

                panel_waitlist.Hide();
            }
        }

        private void InPatients_Load(object sender, EventArgs e)
        {
            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT MAX(INPATIENT_ID) as id FROM INPATIENTRECORD ");

            rs.Read();

            int x = rs.GetInt32(0) + 1;

            tbPatientId.Text = x + "";
            tbPatientId.ReadOnly = true;

            // -------a asdjasbdlkjaslkdhasd -- 

            rs = DB.QueryWithResultSet("SELECT * FROM PATIENT");

            while (rs.Read())
            {
                cbPatientNo.Items.Add(rs.GetString(0) + "-" + rs.GetString(1) + " " + rs.GetString(2));
            }
        }
    }
}
