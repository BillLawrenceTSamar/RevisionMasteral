﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalSanitariumMIS;
using IBM.Data.DB2;

namespace LogIn
{
    public partial class InventoryMovement : Form
    {
        private FinalSanitariumMIS.Helpers.DatabaseHelper DB;

        public InventoryMovement()
        {
            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper();
            InitializeComponent();
        }

        private void InventoryMovement_Load(object sender, EventArgs e)
        {
            loadFilters();
            loadMovements();
        }

        private List<String> IDS;

        private void loadFilters() {

            IDS = new List<string>();

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM SUPPLIER");
            cb_filter.Items.Add("ALL");

            while (rs.Read())
            {
                IDS.Add(rs["SUPPLIER_NUMBER"].ToString());
                cb_filter.Items.Add(rs["SUPPLIER_NAME"].ToString());
            }
        }

        private void loadMovements()
        {
            dgv_movements.Rows.Clear();

            String Condition = "";

            if (cb_filter.SelectedIndex > 0)
            {
                Condition = "WHERE SUPPLIER_NUMBER = " + IDS[cb_filter.SelectedIndex -1];
            }

            DB2ResultSet rs = DB.QueryWithResultSet("SELECT * FROM supply_in_history " + Condition + " ORDER BY action_date DESC");

            while (rs.Read())
            {
                DB2ResultSet srs1 = DB.QueryWithResultSet("SELECT * FROM supply WHERE ITEM_NUMBER = " + rs["ITEM_NUMBER"].ToString());
                DB2ResultSet srs2 = DB.QueryWithResultSet("SELECT * FROM supplier WHERE SUPPLIER_NUMBER  = " + rs["SUPPLIER_NUMBER"].ToString());

                srs1.Read();
                srs2.Read();

                if (tb_search.Text != "")
                {
                    String itemname = srs1["ITEM_NAME"].ToString();
                    String search = tb_search.Text;

                    itemname = itemname.ToLower();
                    search = search.ToLower();

                    if (itemname.IndexOf(search) > -1)
                    {
                        dgv_movements.Rows.Add(new String[] {
                            rs["QUANTITY"].ToString(),
                            srs1["ITEM_NAME"].ToString(),
                            srs1["DESCRIPTION"].ToString(),
                            srs1["UNIT"].ToString(),
                            srs2["SUPPLIER_NAME"].ToString(),
                            rs["ACTION_DATE"].ToString()
                        });
                    }
                }
                else
                {
                    dgv_movements.Rows.Add(new String[] {
                        rs["QUANTITY"].ToString(),
                        srs1["ITEM_NAME"].ToString(),
                        srs1["DESCRIPTION"].ToString(),
                        srs1["UNIT"].ToString(),
                        srs2["SUPPLIER_NAME"].ToString(),
                        rs["ACTION_DATE"].ToString()
                    });
                }
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            loadMovements();
        }
    }
}
