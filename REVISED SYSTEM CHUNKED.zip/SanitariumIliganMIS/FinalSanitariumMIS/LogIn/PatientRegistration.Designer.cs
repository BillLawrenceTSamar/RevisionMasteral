﻿namespace LogIn
{
    partial class PatientRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbmaritalstat = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpbirthdate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.cbsex = new System.Windows.Forms.ComboBox();
            this.txtpatienttelnum = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtpatientlname = new System.Windows.Forms.TextBox();
            this.txtpatientaddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpatientnum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpatientfname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtrelationship = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtnoktelnum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtnoklname = new System.Windows.Forms.TextBox();
            this.txtnokaddress = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtnoknum = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtnokfname = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dgpatientlist = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnregister = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.cb_search_filter = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpatientlist)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.cb_search_filter);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1664, 123);
            this.panel1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Raleway", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(15, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(304, 31);
            this.label4.TabIndex = 7;
            this.label4.Text = "Patient Master Records";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Raleway", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(15, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(437, 44);
            this.label3.TabIndex = 6;
            this.label3.Text = "SANITARIUM HOSPITAL";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cbmaritalstat);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.dtpbirthdate);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cbsex);
            this.groupBox2.Controls.Add(this.txtpatienttelnum);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtpatientlname);
            this.groupBox2.Controls.Add(this.txtpatientaddress);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtpatientnum);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtpatientfname);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(22, 148);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(451, 394);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PERSONAL INFORMATION";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(54, 349);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 18);
            this.label8.TabIndex = 73;
            this.label8.Text = "MARITAL STATUS:";
            // 
            // cbmaritalstat
            // 
            this.cbmaritalstat.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbmaritalstat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbmaritalstat.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbmaritalstat.FormattingEnabled = true;
            this.cbmaritalstat.Location = new System.Drawing.Point(197, 345);
            this.cbmaritalstat.Margin = new System.Windows.Forms.Padding(4);
            this.cbmaritalstat.Name = "cbmaritalstat";
            this.cbmaritalstat.Size = new System.Drawing.Size(236, 26);
            this.cbmaritalstat.TabIndex = 72;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(150, 312);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 18);
            this.label7.TabIndex = 71;
            this.label7.Text = "SEX:";
            // 
            // dtpbirthdate
            // 
            this.dtpbirthdate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dtpbirthdate.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpbirthdate.Location = new System.Drawing.Point(197, 273);
            this.dtpbirthdate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpbirthdate.Name = "dtpbirthdate";
            this.dtpbirthdate.Size = new System.Drawing.Size(236, 25);
            this.dtpbirthdate.TabIndex = 70;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(91, 276);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 18);
            this.label6.TabIndex = 69;
            this.label6.Text = "BIRTH DATE:";
            // 
            // cbsex
            // 
            this.cbsex.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbsex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbsex.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbsex.FormattingEnabled = true;
            this.cbsex.Location = new System.Drawing.Point(197, 308);
            this.cbsex.Margin = new System.Windows.Forms.Padding(4);
            this.cbsex.Name = "cbsex";
            this.cbsex.Size = new System.Drawing.Size(236, 26);
            this.cbsex.TabIndex = 57;
            // 
            // txtpatienttelnum
            // 
            this.txtpatienttelnum.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtpatienttelnum.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatienttelnum.Location = new System.Drawing.Point(197, 238);
            this.txtpatienttelnum.Margin = new System.Windows.Forms.Padding(5);
            this.txtpatienttelnum.Name = "txtpatienttelnum";
            this.txtpatienttelnum.Size = new System.Drawing.Size(236, 25);
            this.txtpatienttelnum.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 242);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 18);
            this.label5.TabIndex = 67;
            this.label5.Text = "TELEPHONE NUMBER:";
            // 
            // txtpatientlname
            // 
            this.txtpatientlname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtpatientlname.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatientlname.Location = new System.Drawing.Point(197, 119);
            this.txtpatientlname.Margin = new System.Windows.Forms.Padding(5);
            this.txtpatientlname.Name = "txtpatientlname";
            this.txtpatientlname.Size = new System.Drawing.Size(236, 25);
            this.txtpatientlname.TabIndex = 66;
            // 
            // txtpatientaddress
            // 
            this.txtpatientaddress.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtpatientaddress.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatientaddress.Location = new System.Drawing.Point(197, 156);
            this.txtpatientaddress.Margin = new System.Windows.Forms.Padding(5);
            this.txtpatientaddress.Multiline = true;
            this.txtpatientaddress.Name = "txtpatientaddress";
            this.txtpatientaddress.Size = new System.Drawing.Size(236, 70);
            this.txtpatientaddress.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(108, 159);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 63;
            this.label2.Text = "ADDRESS:";
            // 
            // txtpatientnum
            // 
            this.txtpatientnum.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtpatientnum.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatientnum.Location = new System.Drawing.Point(197, 42);
            this.txtpatientnum.Margin = new System.Windows.Forms.Padding(5);
            this.txtpatientnum.Name = "txtpatientnum";
            this.txtpatientnum.Size = new System.Drawing.Size(236, 25);
            this.txtpatientnum.TabIndex = 60;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 18);
            this.label1.TabIndex = 59;
            this.label1.Text = "PATIENT NUMBER:";
            // 
            // txtpatientfname
            // 
            this.txtpatientfname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtpatientfname.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatientfname.Location = new System.Drawing.Point(197, 80);
            this.txtpatientfname.Margin = new System.Windows.Forms.Padding(5);
            this.txtpatientfname.Name = "txtpatientfname";
            this.txtpatientfname.Size = new System.Drawing.Size(236, 25);
            this.txtpatientfname.TabIndex = 58;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(88, 83);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 18);
            this.label15.TabIndex = 56;
            this.label15.Text = "FIRST NAME:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(92, 123);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 18);
            this.label11.TabIndex = 20;
            this.label11.Text = "LAST NAME:";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.txtrelationship);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtnoktelnum);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtnoklname);
            this.groupBox1.Controls.Add(this.txtnokaddress);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtnoknum);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtnokfname);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(22, 550);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(451, 308);
            this.groupBox1.TabIndex = 74;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NEXT-OF-KIN INFORMATION";
            // 
            // txtrelationship
            // 
            this.txtrelationship.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtrelationship.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrelationship.Location = new System.Drawing.Point(221, 271);
            this.txtrelationship.Margin = new System.Windows.Forms.Padding(5);
            this.txtrelationship.Name = "txtrelationship";
            this.txtrelationship.Size = new System.Drawing.Size(212, 25);
            this.txtrelationship.TabIndex = 70;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 274);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(204, 18);
            this.label9.TabIndex = 69;
            this.label9.Text = "RELATIONSHIP TO PATIENT:";
            // 
            // txtnoktelnum
            // 
            this.txtnoktelnum.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtnoktelnum.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoktelnum.Location = new System.Drawing.Point(197, 236);
            this.txtnoktelnum.Margin = new System.Windows.Forms.Padding(5);
            this.txtnoktelnum.Name = "txtnoktelnum";
            this.txtnoktelnum.Size = new System.Drawing.Size(236, 25);
            this.txtnoktelnum.TabIndex = 68;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(20, 240);
            this.label13.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(168, 18);
            this.label13.TabIndex = 67;
            this.label13.Text = "TELEPHONE NUMBER:";
            // 
            // txtnoklname
            // 
            this.txtnoklname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtnoklname.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoklname.Location = new System.Drawing.Point(197, 116);
            this.txtnoklname.Margin = new System.Windows.Forms.Padding(5);
            this.txtnoklname.Name = "txtnoklname";
            this.txtnoklname.Size = new System.Drawing.Size(236, 25);
            this.txtnoklname.TabIndex = 66;
            // 
            // txtnokaddress
            // 
            this.txtnokaddress.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtnokaddress.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnokaddress.Location = new System.Drawing.Point(197, 155);
            this.txtnokaddress.Margin = new System.Windows.Forms.Padding(5);
            this.txtnokaddress.Multiline = true;
            this.txtnokaddress.Name = "txtnokaddress";
            this.txtnokaddress.Size = new System.Drawing.Size(236, 70);
            this.txtnokaddress.TabIndex = 64;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(109, 158);
            this.label14.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 18);
            this.label14.TabIndex = 63;
            this.label14.Text = "ADDRESS:";
            // 
            // txtnoknum
            // 
            this.txtnoknum.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtnoknum.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnoknum.Location = new System.Drawing.Point(197, 40);
            this.txtnoknum.Margin = new System.Windows.Forms.Padding(5);
            this.txtnoknum.Name = "txtnoknum";
            this.txtnoknum.Size = new System.Drawing.Size(236, 25);
            this.txtnoknum.TabIndex = 60;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(13, 43);
            this.label16.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(175, 18);
            this.label16.TabIndex = 59;
            this.label16.Text = "NEXT-OF-KIN NUMBER:";
            // 
            // txtnokfname
            // 
            this.txtnokfname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtnokfname.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnokfname.Location = new System.Drawing.Point(197, 77);
            this.txtnokfname.Margin = new System.Windows.Forms.Padding(5);
            this.txtnokfname.Name = "txtnokfname";
            this.txtnokfname.Size = new System.Drawing.Size(236, 25);
            this.txtnokfname.TabIndex = 58;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(89, 80);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 18);
            this.label17.TabIndex = 56;
            this.label17.Text = "FIRST NAME:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(93, 119);
            this.label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(96, 18);
            this.label18.TabIndex = 20;
            this.label18.Text = "LAST NAME:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(487, 135);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(219, 24);
            this.label10.TabIndex = 75;
            this.label10.Text = "PATIENT MASTERLIST:";
            // 
            // dgpatientlist
            // 
            this.dgpatientlist.AllowUserToAddRows = false;
            this.dgpatientlist.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgpatientlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgpatientlist.BackgroundColor = System.Drawing.Color.PaleGreen;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpatientlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgpatientlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgpatientlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpatientlist.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgpatientlist.Location = new System.Drawing.Point(491, 199);
            this.dgpatientlist.Margin = new System.Windows.Forms.Padding(4);
            this.dgpatientlist.Name = "dgpatientlist";
            this.dgpatientlist.ReadOnly = true;
            this.dgpatientlist.RowHeadersVisible = false;
            this.dgpatientlist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgpatientlist.Size = new System.Drawing.Size(1144, 717);
            this.dgpatientlist.TabIndex = 76;
            this.dgpatientlist.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgpatientlist_CellDoubleClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "PID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "FIRSTNAME";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "LASTNAME";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "ADDRESS";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "TELNUMBER";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "BIRTHDATE";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "SEX";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "MARITALSTATUS";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // btnregister
            // 
            this.btnregister.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnregister.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnregister.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnregister.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.Location = new System.Drawing.Point(20, 873);
            this.btnregister.Margin = new System.Windows.Forms.Padding(4);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(237, 43);
            this.btnregister.TabIndex = 79;
            this.btnregister.Text = "REGISTER";
            this.btnregister.UseVisualStyleBackColor = false;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnupdate.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnupdate.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(265, 873);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(208, 43);
            this.btnupdate.TabIndex = 80;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.Location = new System.Drawing.Point(491, 162);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(1033, 30);
            this.tb_search.TabIndex = 82;
            // 
            // btn_search
            // 
            this.btn_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_search.Font = new System.Drawing.Font("Raleway", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(1530, 160);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(105, 32);
            this.btn_search.TabIndex = 83;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // cb_search_filter
            // 
            this.cb_search_filter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_search_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_search_filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_search_filter.FormattingEnabled = true;
            this.cb_search_filter.Items.AddRange(new object[] {
            "Search By Name",
            "Search By Qualification",
            "Search By Experience"});
            this.cb_search_filter.Location = new System.Drawing.Point(1408, 52);
            this.cb_search_filter.Name = "cb_search_filter";
            this.cb_search_filter.Size = new System.Drawing.Size(218, 30);
            this.cb_search_filter.TabIndex = 81;
            this.cb_search_filter.Visible = false;
            // 
            // PatientRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1657, 934);
            this.Controls.Add(this.tb_search);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dgpatientlist);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PatientRegistration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.PatientRegistration_FormClosed);
            this.Load += new System.EventHandler(this.PatientRegistration_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpatientlist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtpatientlname;
        private System.Windows.Forms.TextBox txtpatientaddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpatientnum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpatientfname;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbsex;
        private System.Windows.Forms.TextBox txtpatienttelnum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpbirthdate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbmaritalstat;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtnoktelnum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtnoklname;
        private System.Windows.Forms.TextBox txtnokaddress;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtnoknum;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtnokfname;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtrelationship;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgpatientlist;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.ComboBox cb_search_filter;
    }
}