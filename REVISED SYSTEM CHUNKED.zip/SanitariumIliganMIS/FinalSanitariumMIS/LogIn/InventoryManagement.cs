﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalSanitariumMIS;
using IBM.Data.DB2;

namespace LogIn
{
    public partial class InventoryManagement : Form
    {
        private FinalSanitariumMIS.Helpers.DatabaseHelper DB;
        private int totalQuantity = 0;
        private DB2ResultSet theSupplies;

        public InventoryManagement()
        {
            InitializeComponent();

            DB = new FinalSanitariumMIS.Helpers.DatabaseHelper("127.0.0.1", "50000", "Nicksplat93", "Angelie_Buen", "sanita");
            
        }

        private void loadSupplyList()
        {
            DB2ResultSet supplies = DB.QueryWithResultSet("SELECT * FROM SUPPLY");
            while (supplies.Read())
            {
                dgv_inventory.Rows.Add(new String[] {
                    supplies["ITEM_NUMBER"].ToString(),
                    supplies["ITEM_NAME"].ToString(),
                    supplies["DESCRIPTION"].ToString(),
                    supplies["REORDER_LEVEL"].ToString(),
                    supplies["UNIT"].ToString(),
                    supplies["COST_PER_UNIT"].ToString(),
                    supplies["ITEM_TYPE"].ToString(),
                    supplies["QUANTITY"].ToString()
                });
            }
        }

        private void InventoryManagement_Load(object sender, EventArgs e)
        {
            //tb_dosage.Enabled = false;
            //cb_method_administration.Enabled = false;

            dgv_inventory.Rows.Clear();
            loadSupplyList();

            cb_type_of_supply.Items.Clear();
            cb_type_of_supply.Items.Add("Drugs");
            cb_type_of_supply.Items.Add("Surgical");
            cb_type_of_supply.Items.Add("Non-Surgical");

            cb_filter.Items.Clear();
            cb_filter.Items.Add("Item Name");
            cb_filter.Items.Add("Item Type");

        }

        private void btn_add_stock_Click(object sender, EventArgs e)
        {
            if (tb_stock_quantity.Text == "" || cb_supply_supplier.SelectedIndex == -1)
            {
                MessageBox.Show("Please input Supplier and Quantity");
                return;
            }

            int oldQuantity = 0;
            DB2ResultSet quanti = DB.QueryWithResultSet("SELECT Quantity FROM SUPPLY WHERE ITEM_NUMBER = " + Convert.ToInt32(lblitemnum.Text));
            quanti.Read();
            
            oldQuantity = Convert.ToInt32(quanti["Quantity"].ToString());
            

            totalQuantity = oldQuantity + Convert.ToInt32(tb_stock_quantity.Text);

            DB.Query("UPDATE SUPPLY SET QUANTITY = " + Convert.ToInt32(totalQuantity) + " WHERE ITEM_NUMBER = " + Convert.ToInt32(lblitemnum.Text));

            DB.Query("INSERT INTO SUPPLY_IN_HISTORY (ITEM_NUMBER,SUPPLIER_NUMBER,QUANTITY,ACTION_DATE) VALUES (" + dgv_inventory.CurrentRow.Cells[0].Value.ToString() + "," + supplier_ids[cb_supply_supplier.SelectedIndex] + "," + tb_stock_quantity.Text + ",CURRENT_TIMESTAMP)");

            dgv_inventory.Rows.Clear();
            loadSupplyList();

            tb_stock_quantity.Text = "";
            lblitemname.Text = "Item Name...";
            lblitemnum.Text = "Item Number...";
            panel_add_stock.Visible = false;
            MessageBox.Show("Stock quantity has been successfully updated!");

        }

        private void btn_cancel_add_stock_Click(object sender, EventArgs e)
        {
            tb_stock_quantity.Text = "";
            lblitemname.Text = "Item Name...";
            lblitemnum.Text = "Item Number...";
            panel_add_stock.Visible = false;
        }

        

        private void btn_update_supply_Click(object sender, EventArgs e)
        {
            if ( !tb_supply_name.Text.Equals("")
                && !tb_reorder_level.Text.Equals("") && !tb_unit.Text.Equals("") && !tb_cost_per_unit.Text.Equals("")
                && !cb_type_of_supply.SelectedItem.Equals(""))
            {
                DB2ResultSet check = DB.QueryWithResultSet("SELECT * FROM SUPPLY WHERE ITEM_NUMBER = " + dgv_inventory.CurrentRow.Cells[0].Value.ToString());
                if (check.Read())
                {
        
                        //tb_dosage.Enabled = true;
                        //cb_method_administration.Enabled = true;

                        DB.Query("UPDATE SUPPLY SET " +
                        " ITEM_NAME = '" + tb_supply_name.Text +
                        "', DESCRIPTION = '" + tb_description.Text +
                        "', REORDER_LEVEL = " + Convert.ToInt32(tb_reorder_level.Text) +
                        ", UNIT = '" + tb_unit.Text +
                        "', COST_PER_UNIT = " + Convert.ToDouble(tb_cost_per_unit.Text) +
                        ", ITEM_TYPE = '" + cb_type_of_supply.SelectedItem.ToString() +
                        "' WHERE ITEM_NUMBER = " + dgv_inventory.CurrentRow.Cells[0].Value.ToString());

                    

                    tb_supply_name.Clear();
                    tb_description.Clear();
                    tb_reorder_level.Clear();
                    tb_unit.Clear();
                    tb_cost_per_unit.Clear();
                    cb_type_of_supply.SelectedIndex = -1;

                    loadSupplyList();
                    MessageBox.Show("Record successfully updated!");
                    dgv_inventory.Rows.Clear();
                    loadSupplyList();

                    //tb_dosage.Enabled = false;
                    //cb_method_administration.Enabled = false;
                }
                else
                {
                    MessageBox.Show("That Item Number does not exist. Please select from the Inventory List on the right.");
                }
            }
            else
            {
                MessageBox.Show("Please select (DOUBLE-CLICK) an existing record from the Inventory List on the right.");
            }
        }

        private void btn_save_supply_Click(object sender, EventArgs e)
        {
            if (!tb_supply_name.Text.Equals("")
                && !tb_reorder_level.Text.Equals("") && !tb_unit.Text.Equals("") && !tb_cost_per_unit.Text.Equals("") && !cb_type_of_supply.SelectedItem.Equals(""))
            {
                    MessageBox.Show("INSERT INTO SUPPLY (item_name,description,reorder_level,unit,cost_per_unit,item_type,quantity) VALUES ('" 
                        + tb_supply_name.Text + 
                        "','" + tb_description.Text + 
                        "'," + Convert.ToInt32(tb_reorder_level.Text) + 
                        ",'" + tb_unit.Text + 
                        "'," + Convert.ToDouble(tb_cost_per_unit.Text) + 
                        ",'" + cb_type_of_supply.SelectedItem.ToString() + "',0)");

                    DB.Query("INSERT INTO SUPPLY (item_name,description,reorder_level,unit,cost_per_unit,item_type,quantity) VALUES ('"
                        + tb_supply_name.Text +
                        "','" + tb_description.Text +
                        "'," + Convert.ToInt32(tb_reorder_level.Text) +
                        ",'" + tb_unit.Text +
                        "'," + Convert.ToDouble(tb_cost_per_unit.Text) +
                        ",'" + cb_type_of_supply.SelectedItem.ToString() + "',0)");

                    dgv_inventory.Rows.Clear();
                    loadSupplyList();

                    MessageBox.Show("New Item has been saved!");
                    ClearAllFields();
                    //tb_dosage.Enabled = false;
                    //cb_method_administration.Enabled = false;
                
            }
            else
            {
                MessageBox.Show("Please make sure all fields are correctly filled out.");
            }
        }

        //private void cb_type_of_supply_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (cb_type_of_supply.SelectedItem.Equals("Drugs"))
        //    {
        //        tb_dosage.Enabled = true;
        //        cb_method_administration.Enabled = true;
        //    }
        //    else
        //    {
        //        tb_dosage.Enabled = false;
        //        cb_method_administration.Enabled = false;
        //    }
        //}

        private void ClearAllFields()
        {
            tb_supply_name.Text = "";
            tb_description.Text = "";
            tb_reorder_level.Text = "";
            tb_unit.Text = "";
            tb_cost_per_unit.Text = "";
            cb_type_of_supply.SelectedIndex = -1;
        }

        private void InventoryManagement_FormClosed(object sender, FormClosedEventArgs e)
        {
            MedDirMainMenu frmMD = new MedDirMainMenu();
            frmMD.Show();
            this.Hide();
        }

        private void tb_supplier_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DB2ResultSet check = DB.QueryWithResultSet("SELECT * FROM SUPPLIER WHERE SUPPLIER_NUMBER = ");
                while (check.Read())
                {
                    //lblsuppliername.Text = check["SUPPLIER_NAME"].ToString();
                }
            }
            catch(Exception er)
            {
              //  lblsuppliername.Text = "Supplier does not exist.";
            }
            
        }

        private void inventory_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int rownum = e.RowIndex;

            tb_supply_name.Text = dgv_inventory.Rows[rownum].Cells[1].Value.ToString();
            tb_description.Text = dgv_inventory.Rows[rownum].Cells[2].Value.ToString();
            tb_reorder_level.Text = dgv_inventory.Rows[rownum].Cells[3].Value.ToString();
            tb_unit.Text = dgv_inventory.Rows[rownum].Cells[4].Value.ToString();
            tb_cost_per_unit.Text = dgv_inventory.Rows[rownum].Cells[5].Value.ToString();
            cb_type_of_supply.SelectedItem = dgv_inventory.Rows[rownum].Cells[6].Value.ToString();
        }

        private void btn_show_add_stock_panel_Click(object sender, EventArgs e)
        {
            int selrow = dgv_inventory.CurrentRow.Index;
            refreshSupplySuppliersCB();

            panel_add_stock.Visible = true;

            lblitemnum.Text = dgv_inventory.Rows[selrow].Cells[0].Value.ToString();
            lblitemname.Text = dgv_inventory.Rows[selrow].Cells[1].Value.ToString();


        }

        private void btn_suppliers_Click(object sender, EventArgs e)
        {
            Suppliers frmSuppliers = new Suppliers();
            frmSuppliers.ShowDialog();
            
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void tb_search_TextChanged(object sender, EventArgs e)
        {
            if (tb_search.Text.Equals(""))
            {
                dgv_inventory.Rows.Clear();
                loadSupplyList();
            }
            else
            {
                dgv_inventory.Rows.Clear();

                String varia = "ITEM_NAME";

                if(cb_filter.SelectedIndex > 0)
                {
                    varia = "ITEM_TYPE";
                }

                DB2ResultSet supplies = DB.QueryWithResultSet("SELECT * FROM SUPPLY WHERE LOWER(" + varia + ") LIKE '%" + tb_search.Text + "%' OR UPPER(ITEM_NAME) LIKE '%" + tb_search.Text + "%'");
                while (supplies.Read())
                {

                    dgv_inventory.Rows.Add(new string[] {
                        supplies["ITEM_NUMBER"].ToString(),
                        supplies["ITEM_NAME"].ToString(),
                        supplies["DESCRIPTION"].ToString(),
                        supplies["QUANTITY"].ToString(),
                        supplies["REORDER_LEVEL"].ToString(),
                        supplies["UNIT"].ToString(),
                        supplies["COST_PER_UNIT"].ToString(),
                        supplies["ITEM_TYPE"].ToString(),
                        supplies["QUANTITY"].ToString()
                    });
                }
            }
        }

        private void btn_manage_suppliers_Click(object sender, EventArgs e)
        {

            refreshSupplySuppliers();

            lbl_assigned_supplier.Text = "Assigned Suppliers for " + dgv_inventory.CurrentRow.Cells[1].Value.ToString();
            panel_waitlist.Visible = true;
        }

        private List<String> supplier_ids;

        private void refreshSupplySuppliersCB() {

            cb_supply_supplier.Items.Clear();
            supplier_ids = new List<string>();

            DB2ResultSet knownsuppliers = DB.QueryWithResultSet("SELECT * FROM SUPPLY_SUPPLIER WHERE ITEM_NUMBER = " + dgv_inventory.CurrentRow.Cells[0].Value.ToString());
            while (knownsuppliers.Read())
            {
                DB2ResultSet r = DB.QueryWithResultSet("SELECT * FROM SUPPLIER WHERE SUPPLIER_NUMBER = " + knownsuppliers["SUPPLIER_NUMBER"]);

                r.Read();
                supplier_ids.Add(r["SUPPLIER_NUMBER"].ToString());
                cb_supply_supplier.Items.Add(r["SUPPLIER_NAME"].ToString());
            }
        }

        private void refreshSupplySuppliers()
        {
            dgv_supplier_masterlist.Rows.Clear();
            string[] salist = new string[5];
            DB2ResultSet suppliers = DB.QueryWithResultSet("SELECT * FROM SUPPLIER");
            while (suppliers.Read())
            {
                salist[0] = suppliers["SUPPLIER_NUMBER"].ToString();
                salist[1] = suppliers["SUPPLIER_NAME"].ToString();
                salist[2] = suppliers["ADDRESS"].ToString();
                salist[3] = suppliers["TELNUMBER"].ToString();
                salist[4] = suppliers["FAXNUMBER"].ToString();

                dgv_supplier_masterlist.Rows.Add(salist);
            }

            dgv_supply_suppliers.Rows.Clear();
            DB2ResultSet knownsuppliers = DB.QueryWithResultSet("SELECT * FROM SUPPLY_SUPPLIER WHERE ITEM_NUMBER = " + dgv_inventory.CurrentRow.Cells[0].Value.ToString());
            while (knownsuppliers.Read())
            {
                DB2ResultSet r = DB.QueryWithResultSet("SELECT * FROM SUPPLIER WHERE SUPPLIER_NUMBER = " + knownsuppliers["SUPPLIER_NUMBER"]);

                r.Read();

                dgv_supply_suppliers.Rows.Add(new String[] {
                    r["SUPPLIER_NUMBER"].ToString(),
                    r["SUPPLIER_NAME"].ToString(),
                    r["ADDRESS"].ToString(),
                    r["TELNUMBER"].ToString(),
                    r["FAXNUMBER"].ToString()
                });
            }
        }

        private void label_close_wait_list_Click(object sender, EventArgs e)
        {
            panel_waitlist.Visible = false;
        }

        private void btn_add_as_supplier_Click(object sender, EventArgs e)
        {
            if(dgv_supplier_masterlist.CurrentRow == null)
            {
                return;
            }

            DB2ResultSet r = DB.QueryWithResultSet("SELECT * FROM supply_supplier WHERE supplier_number = " + dgv_supplier_masterlist.CurrentRow.Cells[0].Value.ToString() + " AND item_number = " + dgv_inventory.CurrentRow.Cells[0].Value.ToString());

            if (r.Read())
            {
                MessageBox.Show("Supplier is already listed");
                return;
            }

            DB.Query("INSERT INTO supply_supplier (ITEM_NUMBER, SUPPLIER_NUMBER) VALUES (" + dgv_inventory.CurrentRow.Cells[0].Value.ToString() + "," + dgv_supplier_masterlist.CurrentRow.Cells[0].Value.ToString() + ")");

            refreshSupplySuppliers();
            refreshSupplySuppliersCB();
        }

        private void btn_remove_supply_supplier_Click(object sender, EventArgs e)
        {
            if (dgv_supply_suppliers.CurrentRow == null)
            {
                return;
            }

            DB.Query("DELETE FROM supply_supplier WHERE supplier_number = " + dgv_supply_suppliers.CurrentRow.Cells[0].Value.ToString() + " AND item_number = " + dgv_inventory.CurrentRow.Cells[0].Value.ToString());
            refreshSupplySuppliers();
            refreshSupplySuppliersCB();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new InventoryMovement().ShowDialog();
        }
    }
}
