﻿namespace LogIn
{
    partial class MedDirMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MedDirMainMenu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnpatientregistration = new System.Windows.Forms.Button();
            this.btnrequisitions = new System.Windows.Forms.Button();
            this.btnrooms = new System.Windows.Forms.Button();
            this.btninventory = new System.Windows.Forms.Button();
            this.btnappointments = new System.Windows.Forms.Button();
            this.btn_position_maintenance = new System.Windows.Forms.Button();
            this.btn_salary_maintenance = new System.Windows.Forms.Button();
            this.btn_staff_ward_alloc = new System.Windows.Forms.Button();
            this.btn_StaffRecords = new System.Windows.Forms.Button();
            this.btn_StaffRegistration = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_inpatient = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_medications = new System.Windows.Forms.Button();
            this.lbl_position = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_time = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1531, 123);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Raleway", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(24, 72);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(434, 31);
            this.label4.TabIndex = 9;
            this.label4.Text = "Management Information System";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Raleway", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(24, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(437, 44);
            this.label3.TabIndex = 8;
            this.label3.Text = "SANITARIUM HOSPITAL";
            // 
            // btnpatientregistration
            // 
            this.btnpatientregistration.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnpatientregistration.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnpatientregistration.Enabled = false;
            this.btnpatientregistration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnpatientregistration.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpatientregistration.Image = ((System.Drawing.Image)(resources.GetObject("btnpatientregistration.Image")));
            this.btnpatientregistration.Location = new System.Drawing.Point(31, 209);
            this.btnpatientregistration.Margin = new System.Windows.Forms.Padding(4);
            this.btnpatientregistration.Name = "btnpatientregistration";
            this.btnpatientregistration.Size = new System.Drawing.Size(171, 306);
            this.btnpatientregistration.TabIndex = 1;
            this.btnpatientregistration.Text = "Patient Master Records";
            this.btnpatientregistration.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnpatientregistration.UseVisualStyleBackColor = false;
            this.btnpatientregistration.Click += new System.EventHandler(this.btnpatientregistration_Click);
            // 
            // btnrequisitions
            // 
            this.btnrequisitions.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnrequisitions.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnrequisitions.Enabled = false;
            this.btnrequisitions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnrequisitions.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrequisitions.Image = ((System.Drawing.Image)(resources.GetObject("btnrequisitions.Image")));
            this.btnrequisitions.Location = new System.Drawing.Point(31, 598);
            this.btnrequisitions.Margin = new System.Windows.Forms.Padding(4);
            this.btnrequisitions.Name = "btnrequisitions";
            this.btnrequisitions.Size = new System.Drawing.Size(171, 306);
            this.btnrequisitions.TabIndex = 3;
            this.btnrequisitions.Text = "Hospital Requisitions";
            this.btnrequisitions.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnrequisitions.UseVisualStyleBackColor = false;
            this.btnrequisitions.Click += new System.EventHandler(this.btnrequisitions_Click);
            // 
            // btnrooms
            // 
            this.btnrooms.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnrooms.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnrooms.Enabled = false;
            this.btnrooms.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnrooms.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrooms.Image = ((System.Drawing.Image)(resources.GetObject("btnrooms.Image")));
            this.btnrooms.Location = new System.Drawing.Point(746, 209);
            this.btnrooms.Margin = new System.Windows.Forms.Padding(4);
            this.btnrooms.Name = "btnrooms";
            this.btnrooms.Size = new System.Drawing.Size(171, 306);
            this.btnrooms.TabIndex = 6;
            this.btnrooms.Text = "Room Management";
            this.btnrooms.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnrooms.UseVisualStyleBackColor = false;
            this.btnrooms.Click += new System.EventHandler(this.btnrooms_Click);
            // 
            // btninventory
            // 
            this.btninventory.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btninventory.Cursor = System.Windows.Forms.Cursors.Default;
            this.btninventory.Enabled = false;
            this.btninventory.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btninventory.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninventory.Image = ((System.Drawing.Image)(resources.GetObject("btninventory.Image")));
            this.btninventory.Location = new System.Drawing.Point(926, 209);
            this.btninventory.Margin = new System.Windows.Forms.Padding(4);
            this.btninventory.Name = "btninventory";
            this.btninventory.Size = new System.Drawing.Size(171, 306);
            this.btninventory.TabIndex = 5;
            this.btninventory.Text = "Inventory Management";
            this.btninventory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btninventory.UseVisualStyleBackColor = false;
            this.btninventory.Click += new System.EventHandler(this.btninventory_Click);
            // 
            // btnappointments
            // 
            this.btnappointments.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnappointments.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnappointments.Enabled = false;
            this.btnappointments.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnappointments.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnappointments.Image = ((System.Drawing.Image)(resources.GetObject("btnappointments.Image")));
            this.btnappointments.Location = new System.Drawing.Point(210, 209);
            this.btnappointments.Margin = new System.Windows.Forms.Padding(4);
            this.btnappointments.Name = "btnappointments";
            this.btnappointments.Size = new System.Drawing.Size(171, 306);
            this.btnappointments.TabIndex = 4;
            this.btnappointments.Text = "Out-Patient Records";
            this.btnappointments.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnappointments.UseVisualStyleBackColor = false;
            this.btnappointments.Click += new System.EventHandler(this.btnappointments_Click);
            // 
            // btn_position_maintenance
            // 
            this.btn_position_maintenance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_position_maintenance.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_position_maintenance.Enabled = false;
            this.btn_position_maintenance.FlatAppearance.BorderSize = 0;
            this.btn_position_maintenance.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_position_maintenance.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_position_maintenance.Image = ((System.Drawing.Image)(resources.GetObject("btn_position_maintenance.Image")));
            this.btn_position_maintenance.Location = new System.Drawing.Point(568, 598);
            this.btn_position_maintenance.Margin = new System.Windows.Forms.Padding(4);
            this.btn_position_maintenance.Name = "btn_position_maintenance";
            this.btn_position_maintenance.Size = new System.Drawing.Size(171, 306);
            this.btn_position_maintenance.TabIndex = 64;
            this.btn_position_maintenance.Text = "Position Maintenance";
            this.btn_position_maintenance.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_position_maintenance.UseVisualStyleBackColor = false;
            this.btn_position_maintenance.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_salary_maintenance
            // 
            this.btn_salary_maintenance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_salary_maintenance.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_salary_maintenance.Enabled = false;
            this.btn_salary_maintenance.FlatAppearance.BorderSize = 0;
            this.btn_salary_maintenance.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_salary_maintenance.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salary_maintenance.Image = ((System.Drawing.Image)(resources.GetObject("btn_salary_maintenance.Image")));
            this.btn_salary_maintenance.Location = new System.Drawing.Point(927, 598);
            this.btn_salary_maintenance.Margin = new System.Windows.Forms.Padding(4);
            this.btn_salary_maintenance.Name = "btn_salary_maintenance";
            this.btn_salary_maintenance.Size = new System.Drawing.Size(171, 306);
            this.btn_salary_maintenance.TabIndex = 63;
            this.btn_salary_maintenance.Text = "Salary Maintenance";
            this.btn_salary_maintenance.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_salary_maintenance.UseVisualStyleBackColor = false;
            this.btn_salary_maintenance.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_staff_ward_alloc
            // 
            this.btn_staff_ward_alloc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_staff_ward_alloc.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_staff_ward_alloc.Enabled = false;
            this.btn_staff_ward_alloc.FlatAppearance.BorderSize = 0;
            this.btn_staff_ward_alloc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_staff_ward_alloc.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_staff_ward_alloc.Image = ((System.Drawing.Image)(resources.GetObject("btn_staff_ward_alloc.Image")));
            this.btn_staff_ward_alloc.Location = new System.Drawing.Point(747, 598);
            this.btn_staff_ward_alloc.Margin = new System.Windows.Forms.Padding(4);
            this.btn_staff_ward_alloc.Name = "btn_staff_ward_alloc";
            this.btn_staff_ward_alloc.Size = new System.Drawing.Size(171, 306);
            this.btn_staff_ward_alloc.TabIndex = 62;
            this.btn_staff_ward_alloc.Text = "Staff-Ward Allocation";
            this.btn_staff_ward_alloc.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_staff_ward_alloc.UseVisualStyleBackColor = false;
            this.btn_staff_ward_alloc.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_StaffRecords
            // 
            this.btn_StaffRecords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_StaffRecords.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_StaffRecords.Enabled = false;
            this.btn_StaffRecords.FlatAppearance.BorderSize = 0;
            this.btn_StaffRecords.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_StaffRecords.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_StaffRecords.Image = ((System.Drawing.Image)(resources.GetObject("btn_StaffRecords.Image")));
            this.btn_StaffRecords.Location = new System.Drawing.Point(389, 598);
            this.btn_StaffRecords.Margin = new System.Windows.Forms.Padding(4);
            this.btn_StaffRecords.Name = "btn_StaffRecords";
            this.btn_StaffRecords.Size = new System.Drawing.Size(171, 306);
            this.btn_StaffRecords.TabIndex = 61;
            this.btn_StaffRecords.Text = "Staff Records";
            this.btn_StaffRecords.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_StaffRecords.UseVisualStyleBackColor = false;
            this.btn_StaffRecords.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_StaffRegistration
            // 
            this.btn_StaffRegistration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_StaffRegistration.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_StaffRegistration.Enabled = false;
            this.btn_StaffRegistration.FlatAppearance.BorderSize = 0;
            this.btn_StaffRegistration.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_StaffRegistration.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_StaffRegistration.Image = ((System.Drawing.Image)(resources.GetObject("btn_StaffRegistration.Image")));
            this.btn_StaffRegistration.Location = new System.Drawing.Point(210, 598);
            this.btn_StaffRegistration.Margin = new System.Windows.Forms.Padding(4);
            this.btn_StaffRegistration.Name = "btn_StaffRegistration";
            this.btn_StaffRegistration.Size = new System.Drawing.Size(171, 306);
            this.btn_StaffRegistration.TabIndex = 60;
            this.btn_StaffRegistration.Text = "Staff Registration";
            this.btn_StaffRegistration.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_StaffRegistration.UseVisualStyleBackColor = false;
            this.btn_StaffRegistration.Click += new System.EventHandler(this.btn_StaffRegistration_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Raleway", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 143);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 51);
            this.label1.TabIndex = 57;
            this.label1.Text = "Patients";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Raleway", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(734, 143);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 51);
            this.label2.TabIndex = 58;
            this.label2.Text = "Facilities";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Raleway", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(198, 532);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(510, 51);
            this.label6.TabIndex = 67;
            this.label6.Text = "Personnel Management";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.panel2.Location = new System.Drawing.Point(746, 197);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(351, 5);
            this.panel2.TabIndex = 68;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel3.Location = new System.Drawing.Point(31, 197);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(707, 5);
            this.panel3.TabIndex = 69;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel4.Location = new System.Drawing.Point(210, 586);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(887, 5);
            this.panel4.TabIndex = 69;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Honeydew;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.lbl_time);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.lbl_position);
            this.panel5.Location = new System.Drawing.Point(1120, 197);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(383, 707);
            this.panel5.TabIndex = 70;
            // 
            // btn_inpatient
            // 
            this.btn_inpatient.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn_inpatient.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_inpatient.Enabled = false;
            this.btn_inpatient.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_inpatient.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_inpatient.Image = ((System.Drawing.Image)(resources.GetObject("btn_inpatient.Image")));
            this.btn_inpatient.Location = new System.Drawing.Point(389, 209);
            this.btn_inpatient.Margin = new System.Windows.Forms.Padding(4);
            this.btn_inpatient.Name = "btn_inpatient";
            this.btn_inpatient.Size = new System.Drawing.Size(171, 306);
            this.btn_inpatient.TabIndex = 73;
            this.btn_inpatient.Text = "In-Patient Records";
            this.btn_inpatient.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_inpatient.UseVisualStyleBackColor = false;
            this.btn_inpatient.Click += new System.EventHandler(this.btn_inpatient_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.MediumAquamarine;
            this.panel6.Location = new System.Drawing.Point(31, 586);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(172, 5);
            this.panel6.TabIndex = 69;
            // 
            // btn_medications
            // 
            this.btn_medications.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn_medications.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_medications.Enabled = false;
            this.btn_medications.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_medications.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_medications.Image = ((System.Drawing.Image)(resources.GetObject("btn_medications.Image")));
            this.btn_medications.Location = new System.Drawing.Point(567, 209);
            this.btn_medications.Margin = new System.Windows.Forms.Padding(4);
            this.btn_medications.Name = "btn_medications";
            this.btn_medications.Size = new System.Drawing.Size(171, 306);
            this.btn_medications.TabIndex = 74;
            this.btn_medications.Text = "Medications";
            this.btn_medications.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_medications.UseVisualStyleBackColor = false;
            this.btn_medications.Click += new System.EventHandler(this.btn_medications_Click);
            // 
            // lbl_position
            // 
            this.lbl_position.BackColor = System.Drawing.Color.Silver;
            this.lbl_position.Font = new System.Drawing.Font("Raleway", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_position.Location = new System.Drawing.Point(5, 62);
            this.lbl_position.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_position.Name = "lbl_position";
            this.lbl_position.Size = new System.Drawing.Size(371, 137);
            this.lbl_position.TabIndex = 75;
            this.lbl_position.Text = "Dashboard";
            this.lbl_position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Raleway", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 23);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(371, 37);
            this.label7.TabIndex = 76;
            this.label7.Text = "Logged in as";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_time
            // 
            this.lbl_time.BackColor = System.Drawing.Color.Silver;
            this.lbl_time.Font = new System.Drawing.Font("Raleway", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_time.Location = new System.Drawing.Point(5, 295);
            this.lbl_time.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(371, 49);
            this.lbl_time.TabIndex = 77;
            this.lbl_time.Text = "Dashboard";
            this.lbl_time.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Raleway", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 252);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(371, 37);
            this.label8.TabIndex = 78;
            this.label8.Text = "System Time";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MedDirMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1529, 932);
            this.Controls.Add(this.btn_medications);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.btn_inpatient);
            this.Controls.Add(this.btn_salary_maintenance);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_position_maintenance);
            this.Controls.Add(this.btnrooms);
            this.Controls.Add(this.btninventory);
            this.Controls.Add(this.btn_staff_ward_alloc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_StaffRecords);
            this.Controls.Add(this.btn_StaffRegistration);
            this.Controls.Add(this.btnpatientregistration);
            this.Controls.Add(this.btnrequisitions);
            this.Controls.Add(this.btnappointments);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1547, 979);
            this.Name = "MedDirMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MedDirMainMenu_FormClosed);
            this.Load += new System.EventHandler(this.MedDirMainMenu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnpatientregistration;
        private System.Windows.Forms.Button btnrequisitions;
        private System.Windows.Forms.Button btnrooms;
        private System.Windows.Forms.Button btninventory;
        private System.Windows.Forms.Button btnappointments;
        private System.Windows.Forms.Button btn_position_maintenance;
        private System.Windows.Forms.Button btn_salary_maintenance;
        private System.Windows.Forms.Button btn_staff_ward_alloc;
        private System.Windows.Forms.Button btn_StaffRecords;
        private System.Windows.Forms.Button btn_StaffRegistration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_inpatient;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_medications;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_position;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Timer timer1;
    }
}