﻿namespace LogIn
{
    partial class InventoryManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_type_of_supply = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tb_unit = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_cost_per_unit = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_reorder_level = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_description = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_supply_name = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btn_save_supply = new System.Windows.Forms.Button();
            this.dgv_inventory = new System.Windows.Forms.DataGridView();
            this.btn_show_add_stock_panel = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.btn_suppliers = new System.Windows.Forms.Button();
            this.btn_update_supply = new System.Windows.Forms.Button();
            this.panel_add_stock = new System.Windows.Forms.Panel();
            this.lblitemnum = new System.Windows.Forms.Label();
            this.btn_cancel_add_stock = new System.Windows.Forms.Button();
            this.lblitemname = new System.Windows.Forms.Label();
            this.btn_add_stock = new System.Windows.Forms.Button();
            this.tb_stock_quantity = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cb_supply_supplier = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_manage_suppliers = new System.Windows.Forms.Button();
            this.panel_waitlist = new System.Windows.Forms.Panel();
            this.label_close_wait_list = new System.Windows.Forms.Label();
            this.lbl_assigned_supplier = new System.Windows.Forms.Label();
            this.dgv_supplier_masterlist = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_supply_suppliers = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_remove_supply_supplier = new System.Windows.Forms.Button();
            this.btn_add_as_supplier = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_inventory)).BeginInit();
            this.panel_add_stock.SuspendLayout();
            this.panel_waitlist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_supplier_masterlist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_supply_suppliers)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.SeaGreen;
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1643, 123);
            this.panel1.TabIndex = 90;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Raleway", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(20, 68);
            this.label20.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(307, 31);
            this.label20.TabIndex = 102;
            this.label20.Text = "Inventory Management";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Raleway", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(17, 22);
            this.label23.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(437, 44);
            this.label23.TabIndex = 101;
            this.label23.Text = "SANITARIUM HOSPITAL";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.cb_type_of_supply);
            this.groupBox2.Controls.Add(this.panel_add_stock);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tb_unit);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tb_cost_per_unit);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tb_reorder_level);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.tb_description);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tb_supply_name);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(13, 139);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(440, 569);
            this.groupBox2.TabIndex = 91;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SUPPLY DETAILS";
            // 
            // cb_type_of_supply
            // 
            this.cb_type_of_supply.BackColor = System.Drawing.Color.White;
            this.cb_type_of_supply.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_type_of_supply.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_type_of_supply.FormattingEnabled = true;
            this.cb_type_of_supply.Location = new System.Drawing.Point(194, 268);
            this.cb_type_of_supply.Margin = new System.Windows.Forms.Padding(4);
            this.cb_type_of_supply.Name = "cb_type_of_supply";
            this.cb_type_of_supply.Size = new System.Drawing.Size(212, 26);
            this.cb_type_of_supply.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(39, 272);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 18);
            this.label10.TabIndex = 87;
            this.label10.Text = "TYPE OF SUPPLY:";
            // 
            // tb_unit
            // 
            this.tb_unit.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_unit.Location = new System.Drawing.Point(193, 194);
            this.tb_unit.Margin = new System.Windows.Forms.Padding(5);
            this.tb_unit.Name = "tb_unit";
            this.tb_unit.Size = new System.Drawing.Size(212, 25);
            this.tb_unit.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(124, 198);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 18);
            this.label6.TabIndex = 85;
            this.label6.Text = "UNIT:";
            // 
            // tb_cost_per_unit
            // 
            this.tb_cost_per_unit.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_cost_per_unit.Location = new System.Drawing.Point(193, 231);
            this.tb_cost_per_unit.Margin = new System.Windows.Forms.Padding(5);
            this.tb_cost_per_unit.Name = "tb_cost_per_unit";
            this.tb_cost_per_unit.Size = new System.Drawing.Size(212, 25);
            this.tb_cost_per_unit.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(49, 235);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 18);
            this.label2.TabIndex = 83;
            this.label2.Text = "COST PER UNIT:";
            // 
            // tb_reorder_level
            // 
            this.tb_reorder_level.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_reorder_level.Location = new System.Drawing.Point(193, 157);
            this.tb_reorder_level.Margin = new System.Windows.Forms.Padding(5);
            this.tb_reorder_level.Name = "tb_reorder_level";
            this.tb_reorder_level.Size = new System.Drawing.Size(212, 25);
            this.tb_reorder_level.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 161);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 18);
            this.label7.TabIndex = 79;
            this.label7.Text = "REORDER LEVEL:";
            // 
            // tb_description
            // 
            this.tb_description.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_description.Location = new System.Drawing.Point(193, 80);
            this.tb_description.Margin = new System.Windows.Forms.Padding(5);
            this.tb_description.Multiline = true;
            this.tb_description.Name = "tb_description";
            this.tb_description.Size = new System.Drawing.Size(212, 67);
            this.tb_description.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(62, 83);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 18);
            this.label5.TabIndex = 67;
            this.label5.Text = "DESCRIPTION:";
            // 
            // tb_supply_name
            // 
            this.tb_supply_name.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_supply_name.Location = new System.Drawing.Point(193, 43);
            this.tb_supply_name.Margin = new System.Windows.Forms.Padding(5);
            this.tb_supply_name.Name = "tb_supply_name";
            this.tb_supply_name.Size = new System.Drawing.Size(212, 25);
            this.tb_supply_name.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(28, 46);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 18);
            this.label15.TabIndex = 56;
            this.label15.Text = "ITEM/DRUG NAME:";
            // 
            // btn_save_supply
            // 
            this.btn_save_supply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_save_supply.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_save_supply.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_save_supply.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save_supply.Location = new System.Drawing.Point(13, 719);
            this.btn_save_supply.Margin = new System.Windows.Forms.Padding(4);
            this.btn_save_supply.Name = "btn_save_supply";
            this.btn_save_supply.Size = new System.Drawing.Size(213, 43);
            this.btn_save_supply.TabIndex = 11;
            this.btn_save_supply.Text = "SAVE SUPPLY DETAILS";
            this.btn_save_supply.UseVisualStyleBackColor = false;
            this.btn_save_supply.Click += new System.EventHandler(this.btn_save_supply_Click);
            // 
            // dgv_inventory
            // 
            this.dgv_inventory.AllowUserToAddRows = false;
            this.dgv_inventory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_inventory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_inventory.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgv_inventory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_inventory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgv_inventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_inventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column8,
            this.Column11});
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_inventory.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgv_inventory.Location = new System.Drawing.Point(461, 181);
            this.dgv_inventory.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_inventory.MultiSelect = false;
            this.dgv_inventory.Name = "dgv_inventory";
            this.dgv_inventory.ReadOnly = true;
            this.dgv_inventory.RowHeadersVisible = false;
            this.dgv_inventory.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgv_inventory.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_inventory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_inventory.Size = new System.Drawing.Size(1167, 527);
            this.dgv_inventory.TabIndex = 93;
            this.dgv_inventory.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.inventory_CellContentDoubleClick);
            // 
            // btn_show_add_stock_panel
            // 
            this.btn_show_add_stock_panel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_show_add_stock_panel.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_show_add_stock_panel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_show_add_stock_panel.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_show_add_stock_panel.Location = new System.Drawing.Point(1107, 719);
            this.btn_show_add_stock_panel.Margin = new System.Windows.Forms.Padding(4);
            this.btn_show_add_stock_panel.Name = "btn_show_add_stock_panel";
            this.btn_show_add_stock_panel.Size = new System.Drawing.Size(262, 43);
            this.btn_show_add_stock_panel.TabIndex = 94;
            this.btn_show_add_stock_panel.Text = "ADD STOCK";
            this.btn_show_add_stock_panel.UseVisualStyleBackColor = false;
            this.btn_show_add_stock_panel.Click += new System.EventHandler(this.btn_show_add_stock_panel_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(462, 144);
            this.label16.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 24);
            this.label16.TabIndex = 95;
            this.label16.Text = "INVENTORY:";
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1188, 143);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(203, 24);
            this.label17.TabIndex = 96;
            this.label17.Text = "Type of Supply Filter:";
            // 
            // cb_filter
            // 
            this.cb_filter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_filter.BackColor = System.Drawing.Color.White;
            this.cb_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_filter.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(1413, 142);
            this.cb_filter.Margin = new System.Windows.Forms.Padding(4);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(215, 26);
            this.cb_filter.TabIndex = 13;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // btn_suppliers
            // 
            this.btn_suppliers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_suppliers.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_suppliers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_suppliers.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_suppliers.Location = new System.Drawing.Point(1377, 719);
            this.btn_suppliers.Margin = new System.Windows.Forms.Padding(4);
            this.btn_suppliers.Name = "btn_suppliers";
            this.btn_suppliers.Size = new System.Drawing.Size(251, 43);
            this.btn_suppliers.TabIndex = 97;
            this.btn_suppliers.Text = "MANAGE KNOWN SUPPLIERS";
            this.btn_suppliers.UseVisualStyleBackColor = false;
            this.btn_suppliers.Click += new System.EventHandler(this.btn_suppliers_Click);
            // 
            // btn_update_supply
            // 
            this.btn_update_supply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_update_supply.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_update_supply.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_update_supply.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update_supply.Location = new System.Drawing.Point(234, 719);
            this.btn_update_supply.Margin = new System.Windows.Forms.Padding(4);
            this.btn_update_supply.Name = "btn_update_supply";
            this.btn_update_supply.Size = new System.Drawing.Size(219, 43);
            this.btn_update_supply.TabIndex = 98;
            this.btn_update_supply.Text = "UPDATE SUPPLY DETAILS";
            this.btn_update_supply.UseVisualStyleBackColor = false;
            this.btn_update_supply.Click += new System.EventHandler(this.btn_update_supply_Click);
            // 
            // panel_add_stock
            // 
            this.panel_add_stock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_add_stock.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel_add_stock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_add_stock.Controls.Add(this.btn_manage_suppliers);
            this.panel_add_stock.Controls.Add(this.cb_supply_supplier);
            this.panel_add_stock.Controls.Add(this.label1);
            this.panel_add_stock.Controls.Add(this.lblitemnum);
            this.panel_add_stock.Controls.Add(this.btn_cancel_add_stock);
            this.panel_add_stock.Controls.Add(this.lblitemname);
            this.panel_add_stock.Controls.Add(this.btn_add_stock);
            this.panel_add_stock.Controls.Add(this.tb_stock_quantity);
            this.panel_add_stock.Controls.Add(this.label19);
            this.panel_add_stock.Controls.Add(this.label18);
            this.panel_add_stock.Location = new System.Drawing.Point(9, 302);
            this.panel_add_stock.Margin = new System.Windows.Forms.Padding(4);
            this.panel_add_stock.Name = "panel_add_stock";
            this.panel_add_stock.Size = new System.Drawing.Size(420, 300);
            this.panel_add_stock.TabIndex = 99;
            this.panel_add_stock.Visible = false;
            // 
            // lblitemnum
            // 
            this.lblitemnum.AutoSize = true;
            this.lblitemnum.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemnum.Location = new System.Drawing.Point(36, 64);
            this.lblitemnum.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblitemnum.Name = "lblitemnum";
            this.lblitemnum.Size = new System.Drawing.Size(163, 24);
            this.lblitemnum.TabIndex = 104;
            this.lblitemnum.Text = "ITEM NUMBER...";
            // 
            // btn_cancel_add_stock
            // 
            this.btn_cancel_add_stock.BackColor = System.Drawing.Color.Firebrick;
            this.btn_cancel_add_stock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_cancel_add_stock.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel_add_stock.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_cancel_add_stock.Location = new System.Drawing.Point(295, 240);
            this.btn_cancel_add_stock.Margin = new System.Windows.Forms.Padding(4);
            this.btn_cancel_add_stock.Name = "btn_cancel_add_stock";
            this.btn_cancel_add_stock.Size = new System.Drawing.Size(112, 43);
            this.btn_cancel_add_stock.TabIndex = 103;
            this.btn_cancel_add_stock.Text = "CANCEL";
            this.btn_cancel_add_stock.UseVisualStyleBackColor = false;
            this.btn_cancel_add_stock.Click += new System.EventHandler(this.btn_cancel_add_stock_Click);
            // 
            // lblitemname
            // 
            this.lblitemname.AutoSize = true;
            this.lblitemname.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemname.Location = new System.Drawing.Point(35, 87);
            this.lblitemname.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblitemname.Name = "lblitemname";
            this.lblitemname.Size = new System.Drawing.Size(238, 24);
            this.lblitemname.TabIndex = 102;
            this.lblitemname.Text = "PRODUCT NAME HERE...";
            // 
            // btn_add_stock
            // 
            this.btn_add_stock.BackColor = System.Drawing.Color.Gold;
            this.btn_add_stock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_add_stock.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_stock.Location = new System.Drawing.Point(207, 239);
            this.btn_add_stock.Margin = new System.Windows.Forms.Padding(4);
            this.btn_add_stock.Name = "btn_add_stock";
            this.btn_add_stock.Size = new System.Drawing.Size(80, 43);
            this.btn_add_stock.TabIndex = 101;
            this.btn_add_stock.Text = "ADD";
            this.btn_add_stock.UseVisualStyleBackColor = false;
            this.btn_add_stock.Click += new System.EventHandler(this.btn_add_stock_Click);
            // 
            // tb_stock_quantity
            // 
            this.tb_stock_quantity.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_stock_quantity.Location = new System.Drawing.Point(149, 186);
            this.tb_stock_quantity.Margin = new System.Windows.Forms.Padding(5);
            this.tb_stock_quantity.Name = "tb_stock_quantity";
            this.tb_stock_quantity.Size = new System.Drawing.Size(258, 31);
            this.tb_stock_quantity.TabIndex = 96;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(26, 189);
            this.label19.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(113, 24);
            this.label19.TabIndex = 95;
            this.label19.Text = "QUANTITY:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Raleway", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(13, 14);
            this.label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(250, 31);
            this.label18.TabIndex = 100;
            this.label18.Text = "ADD STOCKS FOR:";
            // 
            // tb_search
            // 
            this.tb_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_search.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_search.Location = new System.Drawing.Point(946, 143);
            this.tb_search.Margin = new System.Windows.Forms.Padding(5);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(212, 25);
            this.tb_search.TabIndex = 12;
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(858, 144);
            this.label22.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 24);
            this.label22.TabIndex = 100;
            this.label22.Text = "Search:";
            // 
            // cb_supply_supplier
            // 
            this.cb_supply_supplier.BackColor = System.Drawing.Color.White;
            this.cb_supply_supplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_supply_supplier.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_supply_supplier.FormattingEnabled = true;
            this.cb_supply_supplier.Location = new System.Drawing.Point(148, 137);
            this.cb_supply_supplier.Margin = new System.Windows.Forms.Padding(4);
            this.cb_supply_supplier.Name = "cb_supply_supplier";
            this.cb_supply_supplier.Size = new System.Drawing.Size(259, 32);
            this.cb_supply_supplier.TabIndex = 88;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 140);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 24);
            this.label1.TabIndex = 89;
            this.label1.Text = "SUPPLIER:";
            // 
            // btn_manage_suppliers
            // 
            this.btn_manage_suppliers.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_manage_suppliers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_manage_suppliers.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_manage_suppliers.Location = new System.Drawing.Point(25, 239);
            this.btn_manage_suppliers.Margin = new System.Windows.Forms.Padding(4);
            this.btn_manage_suppliers.Name = "btn_manage_suppliers";
            this.btn_manage_suppliers.Size = new System.Drawing.Size(174, 43);
            this.btn_manage_suppliers.TabIndex = 105;
            this.btn_manage_suppliers.Text = "STOCK SUPPLIERS";
            this.btn_manage_suppliers.UseVisualStyleBackColor = false;
            this.btn_manage_suppliers.Click += new System.EventHandler(this.btn_manage_suppliers_Click);
            // 
            // panel_waitlist
            // 
            this.panel_waitlist.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_waitlist.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel_waitlist.Controls.Add(this.btn_add_as_supplier);
            this.panel_waitlist.Controls.Add(this.btn_remove_supply_supplier);
            this.panel_waitlist.Controls.Add(this.label4);
            this.panel_waitlist.Controls.Add(this.label3);
            this.panel_waitlist.Controls.Add(this.dgv_supply_suppliers);
            this.panel_waitlist.Controls.Add(this.label_close_wait_list);
            this.panel_waitlist.Controls.Add(this.lbl_assigned_supplier);
            this.panel_waitlist.Controls.Add(this.dgv_supplier_masterlist);
            this.panel_waitlist.Location = new System.Drawing.Point(563, 160);
            this.panel_waitlist.Margin = new System.Windows.Forms.Padding(4);
            this.panel_waitlist.Name = "panel_waitlist";
            this.panel_waitlist.Size = new System.Drawing.Size(903, 551);
            this.panel_waitlist.TabIndex = 101;
            this.panel_waitlist.Visible = false;
            // 
            // label_close_wait_list
            // 
            this.label_close_wait_list.AutoSize = true;
            this.label_close_wait_list.Font = new System.Drawing.Font("Raleway", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_close_wait_list.Location = new System.Drawing.Point(778, 18);
            this.label_close_wait_list.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label_close_wait_list.Name = "label_close_wait_list";
            this.label_close_wait_list.Size = new System.Drawing.Size(101, 31);
            this.label_close_wait_list.TabIndex = 87;
            this.label_close_wait_list.Text = "CLOSE";
            this.label_close_wait_list.Click += new System.EventHandler(this.label_close_wait_list_Click);
            // 
            // lbl_assigned_supplier
            // 
            this.lbl_assigned_supplier.AutoSize = true;
            this.lbl_assigned_supplier.Font = new System.Drawing.Font("Raleway", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_assigned_supplier.Location = new System.Drawing.Point(28, 18);
            this.lbl_assigned_supplier.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_assigned_supplier.Name = "lbl_assigned_supplier";
            this.lbl_assigned_supplier.Size = new System.Drawing.Size(294, 31);
            this.lbl_assigned_supplier.TabIndex = 86;
            this.lbl_assigned_supplier.Text = "Assigned Suppliers for";
            // 
            // dgv_supplier_masterlist
            // 
            this.dgv_supplier_masterlist.AllowUserToAddRows = false;
            this.dgv_supplier_masterlist.AllowUserToResizeColumns = false;
            this.dgv_supplier_masterlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_supplier_masterlist.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgv_supplier_masterlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_supplier_masterlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13});
            this.dgv_supplier_masterlist.Location = new System.Drawing.Point(34, 88);
            this.dgv_supplier_masterlist.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_supplier_masterlist.Name = "dgv_supplier_masterlist";
            this.dgv_supplier_masterlist.RowHeadersVisible = false;
            this.dgv_supplier_masterlist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_supplier_masterlist.Size = new System.Drawing.Size(408, 392);
            this.dgv_supplier_masterlist.TabIndex = 85;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Item/Drug #";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Item/Drug Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Description";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Reorder Level";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Unit";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Cost Per Unit";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Type";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Quantity Available";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // dgv_supply_suppliers
            // 
            this.dgv_supply_suppliers.AllowUserToAddRows = false;
            this.dgv_supply_suppliers.AllowUserToResizeColumns = false;
            this.dgv_supply_suppliers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_supply_suppliers.BackgroundColor = System.Drawing.Color.PaleGreen;
            this.dgv_supply_suppliers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_supply_suppliers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dgv_supply_suppliers.Location = new System.Drawing.Point(471, 88);
            this.dgv_supply_suppliers.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_supply_suppliers.Name = "dgv_supply_suppliers";
            this.dgv_supply_suppliers.RowHeadersVisible = false;
            this.dgv_supply_suppliers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_supply_suppliers.Size = new System.Drawing.Size(408, 438);
            this.dgv_supply_suppliers.TabIndex = 98;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 24);
            this.label3.TabIndex = 99;
            this.label3.Text = "Supplier Masterlist:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Raleway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(467, 60);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 24);
            this.label4.TabIndex = 100;
            this.label4.Text = "Supply Suppliers:";
            // 
            // btn_remove_supply_supplier
            // 
            this.btn_remove_supply_supplier.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_remove_supply_supplier.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_remove_supply_supplier.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_remove_supply_supplier.Location = new System.Drawing.Point(232, 490);
            this.btn_remove_supply_supplier.Margin = new System.Windows.Forms.Padding(4);
            this.btn_remove_supply_supplier.Name = "btn_remove_supply_supplier";
            this.btn_remove_supply_supplier.Size = new System.Drawing.Size(210, 36);
            this.btn_remove_supply_supplier.TabIndex = 101;
            this.btn_remove_supply_supplier.Text = "REMOVE";
            this.btn_remove_supply_supplier.UseVisualStyleBackColor = false;
            this.btn_remove_supply_supplier.Click += new System.EventHandler(this.btn_remove_supply_supplier_Click);
            // 
            // btn_add_as_supplier
            // 
            this.btn_add_as_supplier.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_add_as_supplier.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_add_as_supplier.Font = new System.Drawing.Font("Raleway", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_as_supplier.Location = new System.Drawing.Point(34, 490);
            this.btn_add_as_supplier.Margin = new System.Windows.Forms.Padding(4);
            this.btn_add_as_supplier.Name = "btn_add_as_supplier";
            this.btn_add_as_supplier.Size = new System.Drawing.Size(190, 36);
            this.btn_add_as_supplier.TabIndex = 102;
            this.btn_add_as_supplier.Text = "ADD AS SUPPLIER";
            this.btn_add_as_supplier.UseVisualStyleBackColor = false;
            this.btn_add_as_supplier.Click += new System.EventHandler(this.btn_add_as_supplier_Click);
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "ID No";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Name";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Address";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Tel #";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Fax";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "ID No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Address";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Tel #";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Fax";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Raleway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(837, 719);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(262, 43);
            this.button1.TabIndex = 102;
            this.button1.Text = "VIEW STOCK MOVEMENTS";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // InventoryManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1641, 773);
            this.Controls.Add(this.panel_waitlist);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.tb_search);
            this.Controls.Add(this.btn_update_supply);
            this.Controls.Add(this.btn_suppliers);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btn_show_add_stock_panel);
            this.Controls.Add(this.dgv_inventory);
            this.Controls.Add(this.btn_save_supply);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "InventoryManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sanitarium Hospital : Inventory Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InventoryManagement_FormClosed);
            this.Load += new System.EventHandler(this.InventoryManagement_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_inventory)).EndInit();
            this.panel_add_stock.ResumeLayout(false);
            this.panel_add_stock.PerformLayout();
            this.panel_waitlist.ResumeLayout(false);
            this.panel_waitlist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_supplier_masterlist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_supply_suppliers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tb_unit;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_cost_per_unit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_reorder_level;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_description;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_supply_name;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cb_type_of_supply;
        private System.Windows.Forms.Button btn_save_supply;
        private System.Windows.Forms.DataGridView dgv_inventory;
        private System.Windows.Forms.Button btn_show_add_stock_panel;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Button btn_suppliers;
        private System.Windows.Forms.Button btn_update_supply;
        private System.Windows.Forms.Panel panel_add_stock;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tb_stock_quantity;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblitemname;
        private System.Windows.Forms.Button btn_add_stock;
        private System.Windows.Forms.Button btn_cancel_add_stock;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblitemnum;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cb_supply_supplier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_manage_suppliers;
        private System.Windows.Forms.Panel panel_waitlist;
        private System.Windows.Forms.Label label_close_wait_list;
        private System.Windows.Forms.Label lbl_assigned_supplier;
        private System.Windows.Forms.DataGridView dgv_supplier_masterlist;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.Button btn_remove_supply_supplier;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgv_supply_suppliers;
        private System.Windows.Forms.Button btn_add_as_supplier;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.Button button1;
    }
}